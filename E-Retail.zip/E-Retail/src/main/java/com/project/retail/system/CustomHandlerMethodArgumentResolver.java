
package com.project.retail.system;

import java.lang.reflect.ParameterizedType;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.core.convert.support.GenericConversionService;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.project.retail.system.annotation.RequestBodyParam;

/**
 * To use RequestBody (JSON Data) with Parameter. To see This annotation : @RequestBodyParam
 * 
 * @author kamlesh.prajapati
 */
public class CustomHandlerMethodArgumentResolver implements HandlerMethodArgumentResolver {

	
	@Autowired
	private ObjectMapper objectMapper;

	private static final String JSONBODYATTRIBUTE = "JSON_REQUEST_BODY";

	GenericConversionService genericConversionService = new GenericConversionService();

	@Override
	public boolean supportsParameter(MethodParameter parameter) {
		// logger.info("supportsParameter --- parameter.getParameterType() :: -- "
		// + parameter.getParameterType());
		return parameter.hasParameterAnnotation(RequestBodyParam.class);
	}

	@Override
	public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer,
			NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
		// logger.info("resolveArgument --- parameter.getParameterType() :: -- "
		// + parameter.getParameterType());

		JSONObject jsonBody = getRequestBody(webRequest);

		String paramName = parameter.getParameterAnnotation(RequestBodyParam.class).value();
		if (!StringUtils.hasText(paramName)) {
			paramName = parameter.getParameterName();
		}

//		logger.info("parameter :: -- " + parameter.getParameterType() + " ----> " + paramName);

		if (!jsonBody.has(paramName)) {
			return null;
		}

		Object value = jsonBody.get(paramName);
		if (value == null || value.toString().equalsIgnoreCase("null")) {
			return null;
		}
		//logger.info("value :: -- " + value.getClass() +" ---> "+ value); 
		
		
		if (ClassUtils.isPrimitiveOrWrapper(parameter.getParameterType()) 
				|| myWrapper(parameter.getParameterType())
				|| parameter.getParameterType().isEnum()) {
			return objectMapper.convertValue(value, parameter.getParameterType());
		}
		
//		logger.info("Parameter ==>> " +parameter);
//		logger.info("parameter.getGenericParameterType() ==>> " +parameter.getGenericParameterType());
		
//		if(AbstractDocument.class.isAssignableFrom((Class<?>) parameter.getGenericParameterType())){
//			return objectMapper.readValue(value.toString(), parameter.getParameterType());
//		}
		/*
		ParameterizedType ptype1 = (ParameterizedType) parameter.getGenericParameterType();
		
		logger.info(ptype1);
		logger.info(ptype1.getTypeName());
		logger.info(ptype1.getOwnerType());
		logger.info(ptype1.getTypeName().equalsIgnoreCase(" interface java.util.List"));*/
		
		
		if(List.class.isAssignableFrom(parameter.getParameterType()) || Map.class.isAssignableFrom(parameter.getParameterType())){
			ParameterizedType ptype = (ParameterizedType) parameter.getGenericParameterType();
			//logger.info(List.class.isAssignableFrom(parameter.getParameterType()));
			//logger.info("ptype:-- " + ptype);
			return objectMapper.readValue(value.toString(), TypeFactory.defaultInstance().constructType(ptype));
		}
		
	/*	if(parameter.getGenericParameterType() instanceof List || parameter.getGenericParameterType() instanceof Map ){
			ParameterizedType ptype = (ParameterizedType) parameter.getGenericParameterType();
			logger.info("ptype:-- " + ptype);
			return objectMapper.readValue(value.toString(), TypeFactory.defaultInstance().constructType(ptype));
		}*/
		
		if(parameter.getParameterType() == Object.class)
		{
			return value;
		}
		
		return objectMapper.readValue(value.toString(), parameter.getParameterType());
	}

	private JSONObject getRequestBody(NativeWebRequest webRequest) throws Exception {
		HttpServletRequest servletRequest = webRequest.getNativeRequest(HttpServletRequest.class);

		JSONObject jsonBody = (JSONObject) servletRequest.getAttribute(JSONBODYATTRIBUTE);

		if (jsonBody == null) {
			String body = IOUtils.toString(servletRequest.getInputStream());
			jsonBody = new JSONObject(body);
			servletRequest.setAttribute(JSONBODYATTRIBUTE, jsonBody);
		}
		return jsonBody;
	}

	private boolean myWrapper(Class<?> clazz) {

		if (clazz.isAssignableFrom(Date.class) || clazz.isAssignableFrom(String.class) )
			return true;

		return false;

	}

	/*
	 * private Object myConvert(Class<?> target, Object s) throws Exception {
	 * 
	 * // return target.cast(s);
	 * 
	 * logger.info("target --------- " + target);
	 * logger.info(objectMapper.convertValue(s, target));
	 * 
	 * return objectMapper.convertValue(s, target);
	 * 
	 * if (target == Date.class ) { DateFormat df = new
	 * SimpleDateFormat("EEE MMM dd kk:mm:ss zzz yyyy"); return
	 * df.parse(s.toString()); }
	 * 
	 * // throw new IllegalArgumentException("Don't know how to convert to " +
	 * target); }
	 */

}
