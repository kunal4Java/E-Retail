package com.project.retail.system.constants;

public enum UserStatus {
	
	ACTIVE("Active"), INACTIVE("In-Active");
	private final String displayStatus;

	private UserStatus(String displayStatus) {
		this.displayStatus = displayStatus;
	}

	public String getDisplayStatus() {
		return displayStatus;
	}

	@Override
	public String toString() {
		return displayStatus;
	}
}
