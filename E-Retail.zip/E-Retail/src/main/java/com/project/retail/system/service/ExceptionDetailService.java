package com.project.retail.system.service;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.retail.system.dao.ExceptionDetailDao;
import com.project.retail.system.model.ExceptionDetail;
import com.project.retail.system.model.SearchCriteria;
import com.project.retail.system.oauth2.UserDetail;

@Service
public class ExceptionDetailService extends RetailService<ExceptionDetail, String>{

	ExceptionDetailDao exceptionDetailsDao;
	
	Logger logger = Logger.getLogger(getClass());
	
	@Autowired
	public ExceptionDetailService(ExceptionDetailDao exceptionDetailsDao) {
		super(exceptionDetailsDao);
		this.exceptionDetailsDao = exceptionDetailsDao;
	}
	
	public List<ExceptionDetail> search(SearchCriteria searchCriteria, Date from, Date to) {
		return exceptionDetailsDao.search(searchCriteria, from, to);
	}

	public List<ExceptionDetail> searchToday(SearchCriteria searchCriteria) {
		return exceptionDetailsDao.searchToday(searchCriteria);
	}

	/*public void sendExceptionEmail(ExceptionDetail exceptionDetail, String toEmailId) throws Exception  {
		
		EmailTemplateMappingSetting emailTemplateMappingSetting = emailTemplateMappingSettingService.getByType(EmailTemplateEnum.HRMS);
		
		if(emailTemplateMappingSetting != null) {
			
			EmailConfigurationMaster emailConfigurationMaster = emailTemplateMappingSetting.getEmailConfigurationMaster();
			
			if (emailConfigurationMaster != null ) {
				
				String userErrorMessage = "No Error message";
				if(exceptionDetail.getUserMessage() != null) {
					userErrorMessage = exceptionDetail.getUserMessage();
				}
				String emailBody = "<!DOCTYPE html><html>" + "<body>"
						+ "<table border='1' style='width: 100%;'>" + "<tr>"
						+ " <td width='15%'>Client IP :</td>" + " <td>"
						+ exceptionDetail.getIp()
						+ "</td>"
						+ "</tr>"
						+ "<tr>"
						+ "  <td> Client App. version :</td>"
						+ "  <td>"
						+ exceptionDetail.getAppVersion()
						+ "</td>"
						+ "</tr>"
						+ "<tr>"
						+ "  <td> Exception Generated Date Time :</td>"
						+ "  <td>"
						+ DateUtils.getDefaultDateTimeWithDay(exceptionDetail.getDate())
						+ "</td>"
						+ "</tr>"
						+ "<tr>"
						+ "  <td> Logged User Id :</td>"
						+ "  <td>"
						+ exceptionDetail.getUserLoginId()
						+ "["
						+ exceptionDetail.getDisplayName()
						+ "] ["
						+ exceptionDetail.getUserId()
						+ "]"
						+ "</td>"
						+ "</tr>"
						+ "<tr>"
						+ "  <td> PC User Name :</td>"
						+ "  <td>"
						+ exceptionDetail.getPcUserName()
						+ "</td>"
						+ "</tr>"
						+ "<tr>"
						+ "  <td> Operating System :</td>"
						+ "  <td>"
						+ exceptionDetail.getOsName()
						+ "</td>"
						+ "</tr>"
						+ "<tr>"
						+ "  <td> Domain Name :</td>"
						+ "  <td>"
						+ exceptionDetail.getDomainAddress()
						+ "</td>"
						+ "</tr>"
						+ "<tr>"
						+ " <td>Server URL :</td>"
						+ " <td>"
						+ exceptionDetail.getWebServiceUrl()
						+ "</td>"
						+ " </tr><tr>"
						+ "  <td>Error msg :</td>"
						+ "  <td>"
						+ userErrorMessage
						+ "</td></tr>"
						+ "<tr>  <td>Exception msg:</td>"
						+ "  <td>"
						+ exceptionDetail.getExceptionMessage()
						+ "</td></tr><tr>"
						+ "  <td>Exception Detail:</td>"
						+ "  <td>"
						+ exceptionDetail.getExeptionStacktrace()
						+ "</td></tr></table>" + "</body></html>";
				
				// TODO : comment CustomMailUtils.sendMailWithoutAttachment for temporary
				
//				CustomMailUtils.sendMailWithoutAttachment(emailConfigurationMaster, toEmailId, "Exception Detail", emailBody );
				//MailUtils.sendExceptionEmail(toEmailId, "Exception Detail", emailBody);
			}
			
		}
		
		
	}
	*/
	public String addException(String exceptionClass, String exceptionMessage,
			String exceptionStackTrace, String webServiceUrl, String ipAddress) {
		
		ExceptionDetail exceptionDetail = getException();
		
		exceptionDetail.setDate(new Date());
		exceptionDetail.setPriority("Low");
		exceptionDetail.setExceptionClassName(exceptionClass);
		exceptionDetail.setExceptionMessage(exceptionMessage);
		exceptionDetail.setExeptionStacktrace(exceptionStackTrace);
		exceptionDetail.setWebServiceUrl(webServiceUrl);
		exceptionDetail.setAppVersion("Server");
		exceptionDetail.setIp(ipAddress);
		exceptionDetail.setPcUserName(" - ");
		exceptionDetail.setOsName(" - ");
		exceptionDetail.setDomainAddress(" - ");
		save(exceptionDetail);
		return exceptionDetail.getId();
	}
	
	public ExceptionDetail getException() {
		
		ExceptionDetail exceptionDetail = new ExceptionDetail();
		UserDetail userDetail = exceptionDetailsDao.getCurrentLoggedInUser();
		try {
			exceptionDetail.setDisplayName(userDetail.getDisplayUserName());
			exceptionDetail.setUserId(userDetail.getUserMongoId());
			exceptionDetail.setUserLoginId(userDetail.getUserId());
		} catch (Exception e) {
			logger.error(e.getMessage() , e);
		}
		return exceptionDetail;
	}

	public void updateUserMessage(String id, String userMessage) {
		exceptionDetailsDao.updateUserMessage(id, userMessage);
		
	}

}
