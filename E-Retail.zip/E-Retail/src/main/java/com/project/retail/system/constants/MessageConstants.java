package com.project.retail.system.constants;

public class MessageConstants {

	public enum UserMessagesEnum {

		ADD_SUCCESS("${data} added successfully."), UPDATE_SUCCESS(
				"${data} updated successfully."), DELETE_SUCCESS(
				"${data} deleted successfully."), ADD_FAILURE(
				"${data} could not be added."), UPDATE_FAILURE(
				"${data} could not be updated."), DELETE_FAILURE(
				"${data} could not be deleted."), UNIQUE(
				"The ${data} you have entered already exists in the system. Please enter another ${data}"),
				INSUFFICIENT_AMOUNT("Th balance in patient account is insufficient. Available balance : ${data}"),
				REFRENCE_EXIST("This record is being referred in ${data} and so cannot be deleted")
				;

		String message;

		private UserMessagesEnum(String message) {
			this.message = message;
		}

		public String getMessage() {
			return message;
		}

		public String message(String... datas) {
			String msg =  message;
			
			if (this == UNIQUE) {
				if (datas.length > 0) {
					String string = datas[0];
					msg = msg.replace("${data}", string);
				}
			} else {
				for (int i = 0; i < datas.length; i++) {
					String string = datas[i];
					msg= msg.replaceFirst("\\$\\{data\\}", string);
				}
				msg = msg.replace("${data}", "XXX");
			}
			return msg;
		}
	}

	public final static String CHANGE_STATUS = "Status change successfully";
	public final static String MAIL_SEND = "Mail send successfully";
	public final static String ADD_LICENCE = "Licence added successfully";
	public final static String VERSION_ERROR = "Client Not compatible with Server , Please update Your Client Application. ";
	public final static String LOGIN_FAIL_APPLICATION_CODE_DIFFER = "Application Mode Not Compatible with Server";
	public final static String LOGIN_SUC = "Logged in Successfully.";
	public final static String LOGIN_FAIL = "User Name Or Password does not Exist.";
	public final static String INACTIVE_USER = "Sorry, you cannot login as user is inactive.";
	public final static String USER_EMPLOYEE_MAP_SUC = "Employee mapped to User Successfully";
	public final static String USER_ALREADY_MAPPED = "The User you have selected is already mapped to another Employee";
	public final static String USER_NOT_EMPLOYEE = "Sorry, you cannot login as user is not an employee";
	
	//Unit Management
	public static final String UNIT_HEAD_EXIST = "Unit Head For Given Unit Already Exist!";
	//public static final String UNIT_ASSIGN_SUCCESS = "Unit Assigned Successfully";
	//public static final String UNIT_ASSIGNED_ALREADY = "Unit Already Assigned To One of The Doctor";
	//public static final String DR_REMOVED_SUCCESS = "Doctor Removed SuccessFully From Unit";
	
	public final static String LOGOUT_SUC = "Logout Successfully.";

	public final static String PATIENT_FIND_SUC = "Patient found Successfully.";
	public final static String PATIENT_PHOTOUPLOAD_SUC = "Patient's Photo Uploaded Successfully.";

	public static final String VISIT_UPDATE_SUC = "Patient visit updated Successfully.";
	public static final String VISIT_CLOSE_SUC = "Patient visit closed Successfully.";
	public static final String VISIT_BILL_CLOSE_SUC = "Patient visit and bill closed Successfully.";
	public static final String VISIT_CLOSE_SUC_BILL_OPEN = "Patient visit closed Successfully. Bill is not closed.";
	public static final String NO_OPEN_VISIT = "No Open IPD Visit Found For Patient";
	public static final String VISIT_OPD_EXISTS = " OPD Visits Already Open! So Can't Create New OPD Visit";
	public static final String VISIT_IPD_EXISTS = " IPD Visits Already Open! So Can't Create New IPD Visit";
	public static final String SURGERY_IS_OPEN = "Please ensure all surgeries for this patient are closed.";
	public static final String PROCEDURE_IS_OPEN = "Please ensure all procedures for this patient are closed.";
	public static final String IP_REG_IS_OPEN = "Please initiate patient discharge";
	public static final String PATIENT_NOT_DISCHARGED = "Patient is not discharged";
	public static final String IP_REG_NOT_FOUND = "IpRegistration of patient is not Found";
	
	public static final String SUMMARY_DEBIT_FAIL = "Requested amount is not debited because of 'OVER LIMIT'.";

	public static final String REPORT_ACCEPT_SUC = "Patient report accepted Successfully";
	public static final String REPORT_ACCEPT_ERROR = SUMMARY_DEBIT_FAIL	+ " So some Report didn't accept Successfully.";
	public static final String REPORT_ACCEPT_ERROR_STATUS_CONFLICT = "Some Report can not Accepted as they were already Processed";
	public static final String REPORT_CANCEL_ERROR_STATUS_CONFLICT = "Some Report can not Cancelled as they were already Processed";
	public static final String REPORT_CANCEL_ERROR_BILL_CLOSE = "Reports Can Not Cancelled as Bill has been Closed.";
	
	public static final String REPORT_UPDATE_ERROR_STATUS_CONFLICT = "Report can not Update as it is in invalid state, Please Refresh your Screen.";
	
	// Challan
	public static final String CHALLAN_STATUS_PENDING = "Other Challan is already in Pending , Please complete it before creating new Challan";
	
	// Purchase Order
	public static final String PURCHASEORDER_ITEAM_APPROVED_SUC = "PurchaseOrder Request Approved/Disapproved Successfully";
	
	// Supplier Return
	public static final String SUPPLIER_STATUS_PENDING = "Other Supplier Return is already in Pending , Please complete it before creating new Supplier Return.";
	public static final String SUPPLIER_RETURN_ITEM_APPROVED_SUC = "Supplier Return Request Approved/Disapproved Successfully";
	public final static String SUPPLIER_RETURN_FAIL = "Supplier Return Quantity is greater than Available Quantity In Batch";
	
	
	
	// Master
	public final static String MASTER_VERSION_UPDATE_SUC = "Master version updated Successfully.";
	public final static String MASTER_DATA_SUC = "Master Data get Successfully.";

	// itemMaster
	public final static String ITEM_IMAGE_UPLOAD_SUC = "Item Image Uploaded SuccessFully";
	public final static String ITEM_IMAGE_REMOVE_SUC = "Item Image removed SuccessFully";

//	// symptomMaster constant
	public final static String SYMPTOM_MASTER_APPROVED = "Symptom Master approved Successfully";

	public static final String USER_NOT_FOUND = "No User Found For Given Query.";
	public static final String PASSWORD_CHANGE_SUC = "Password Changed Successfully.";
	public static final String USER_PHOTO_UPLOAD_SUC = "User Photo Uploaded Successfully.";
	public static final String PASSWORD_CHANGE_FAILED = "User Does Not Has Role To Change Password.";

	public static final String EXPENSE_ERROR_BILL_CLOSE= "Expense could not be add because bill has been closed";
	public static final String EXPENSE_ERROR_VISIT_CLOSE= "Expense could not be add because visit has been closed";
	public static final String EXPENSE_EMCS_ERROR_LIMIT_EXCEED= "Expense can not be Emcs As Emcs Validity Exceed or Bill is not Emcs";
	public static final String EXPENSE_ADD_DUE_TO_TESTMODE = "Expense Added SuccessFully In TestMode";
	public static final String EXPENSECOLLECTION_ERRORMESSAGE = "Expense could not be add";
	
	// disease master Constant
	public static final String DOCUMENT_UPLOAD_SUCCESSFULLY = "Documents uploaded successfully";
	public static final String DOCUMENT_UPLOAD_FAIL= "Can Not get Patient Insurance From Request";
	
	//Store Master Constants
	public static final String USER_ADDED_TO_STORE="User SuccessFully Added In Store";	
	public static final String USER_REMOVED_FROM_STORE="User SuccessFully Removed From Store";	
	
	// RateContracts Contants
	public static final String RATE_CONTRACTS_DATA_SUC = "Rate Contracts data get Successfully";
	public static final String RATE_CONTRACTS_ALREADY_ACTIVE = "Rate Contract is already Active";
	public static final String RATE_CONTRACTS_INACTIVE = "There is no Active Rate Contract";
	public static final String RATE_CONTRACT_FINALIZE_SUC = "Rate Contract Finalised Successfully";
	public static final String RATE_CONTRACT_ACTIVE_SUC = "Rate Contract Activated Successfully";
	public static final String RATE_CONTRACT_DEACTIVE_SUC = "Rate Contract Deactivated Successfully";
	
	// Rate Contract Supplier
	public static final String RATE_CONTRACT_SUPPLIER_DATA_SUC = "Rate Contract Supplier data get Successfully";

	// Rate Contract Supplier Item
	public static final String RATE_CONTRACT_SUPPLIER_ITEM_DATA_SUC = "Rate Contract SupplierItem get data Successfully";
	public static final String RATE_CONTRACT_LEVEL_ALREADY_ADDED = "This item is already added for this level";
	public static final String RATE_CONTRACT_SUPPLIER_ALREADY_ADDED_ITEM = "This item is already added for this Supplier";

	// Indent
	public static final String INDENT_DATA_SUC = "Indent get data Successfully";
	public static final String PATIENT_INDENT_APPROVED_SUC = "Patient Indent request Approved/Disapproved Successfully";
	public static final String INDENT_REJECT_SUC = "Indent request rejected Successfully";
	public static final String INDENT_ITEM_ISSUE_SET = "Indent Issue Item set successfully";
	public static final String PATIENT_INDENT_ITEM_ISSUED = "Patient Indent item Issued successfully";
	public static final String PATIENT_INDENT_ITEM_RETURNED = "Patient Indent item Returned successfully";
	public static final String INDENT_CLOSE_SUC = "Indent Closed Successfully";
	public static final String PATIENT_INDENT_BILL_CON_SUC = "Patient Indent Bill Confirmed Successfully";

	// Print Setting Master constant
	public static final String PRINT_SETTING_MASTER_IMAGE_SUC = "Print SettingMaster image uploaded successfully";

	// store repair
	public static final String STORE_REPAIR_DELETE_SUC = "Store Repair delete Successfully";

	// Indent Request from Sub to main store
	public static final String SUB_TO_MAIN_REQ_GET_SUC = "Sub Store to  Main Store Indent Request get Successfully";
	public static final String SUB_TO_MAIN_APPROVED_SUC = "Sub Store to Main Store Indent request approved Successfully";
	public static final String SUB_TO_MAIN_ITEM_ISSUED = "Sub Store to Main Store Indent Item Issued Successfully";
	public static final String SUB_TO_MAIN_ITEM_ISSUED_SET = "Sub Store to Main Store Item Issue set Successfully";
	public static final String SUB_TO_MAIN_ITEM_RETURNED = "Sub Store to Main Store Indent Item Returned Successfully";
	public static final String SUB_TO_MAIN_ITEM_CONFIRMED = "Issued Items Confirmed Successfully";
	public static final String SUB_TO_MAIN_ITEM_RECEIVED = "Received Items set Successfully";
  
	// Stock Adjustment 
	public static final String STOCK_ADJUST_REQ_APPROVED_SUC = "Stock Adjustment Request Approved Succesfully";
	
	// Scrap Request for a particular item
    public static final String SCRAP_REQ_QTY_LESS_IN_STOCK = "Requested quantity for Scrap are not present in the Stock";
    public static final String SCRAP_REQ_APPROVED_SUC = "Scrap Request approved Successfully";
    public static final String ITEM_SCRAPPED_SUC = "Item Scrapped Successfully";
    public static final String SCRAP_SELL_CANNOT_UPDATE = "Scrap Sell Can Not Update Because One Of The Scrap Item has Been Sold";
    
    //WorkFlow 
    public static final String WORKFLOW_NOT_PRESENT = "Default WorkFlow for given Item does not exist";
    public static final String WORKFLOW_NOT_PRESENT_FOR_CONCESSION = "No Workflow found for Concession";
    public static final String WORKFLOW_NOT_PRESENT_FOR_UNIT_TRANSFER = "No Workflow found for Unit Transfer";
    public static final String WORKFLOW_NOT_PRESENT_FOR_IPREGESTRATION = "No Workflow found for IpRegistration";
    
    //bed management
    public static final String BED_EXISTS_IN_BLOCK = "Bed Exists in Block so you Cannot delete Block";
//    public static final String BLOCK_OR_BED_EXISTS_IN_WARD = "Bed or Block Exists in Ward so you Cannot delete Ward";
    public static final String CANNOT_ADD_BED_BECAUSE_OF_NUMBERING_TYPE = "Can't add Multiple Bed Or Block When Naming Strategy Is Manual";
    public static final String NURSE_ASSIGNED_TO_OTHER_WARD = "Sister In Charge Or Nurse Already Assigned.";
    public static final String NURSE_DOES_NOT_EXISTS_IN_WARD = "Sister In Charge Or Nurse Does Not Exists In Ward";
    public static final String NURSE_ASSIGNED_TO_OTHER_SISTER = "Nurse Already Assigned.";
    public static final String ITEM_EXISTS_IN_WARD = "Items Exists in Ward so you Cannot delete Block";
    public static final String BED_TRANSFERED_IN_SAME_WARD = "Bed is being transferred to origin.";
    
    
    // Store item return
    public static final String RETURN_ITEM_CONFIRMED_SUC_BY_SUBSTORE = "Return Items Confimred Successfully by SubStore";
    public static final String RETURN_ITEM_CONFIRMED_SUC_BY_MAINSTORE = "Return Items Confirmed Successfully by MainStore";

    //Surgery 
    public static final String SURGERY_CLOSE_ERROR = "Anesthesia Or CPB Still Open So Close It";
    public static final String CPB_ALREADY_CLOSED_BY = "CPB Already Closed By ";
    public static final String CLOSURE_ALREADY_CLOSED_BY = "Closure Already Closed By ";
    public static final String ANESTHESIA_ALREADY_CLOSED_BY = "Anesthesia Already Closed By ";
    public static final String ANESTHESIA_OR_CPB_STILL_NOT_CLOSED = "Anesthesia or CPB Still not Closed, So Close Them First";
 	public static final String SURGERY_DETAILS_UPDATE_SUC = "Surgery Details Updated Successfully";
 	public static final String NO_SURGERY_FOUND = "No Surgery Found For patient's Last Open Visit";
 	
    public static final String STORE_STOCK_NOT_FOUND = "Store Stock Not Found For Given Item And Store";
    
    //Bill 
    public static final String BILL_CLOSE_SUCCESS = "Bill Closed SuccessFully";
    public static final String WAIVE_AMOUNT_SET_SUCCESS = "Waive Amount Set SuccessFully In Bill";
    public static final String BILL_FIND_SUC = "Bill Found successfully";
    public static final String FINAL_BILL_INITIATED_SUCCESS="Final bill initiated successfully.";
    public static final String FINAL_BILL_GENERATED_SUCCESS="Final bill generated successfully.";
    public static final String FINAL_BILL_CANCEL_INITIATED_SUCCESS="Initiated Final Bill Opened successfully";
    public static final String REOPEN_BILL_SUCCESS="Bill has been reopened successfully.";
    public static final String REPORT_PENDING_FINAL_BILL_GENERATE_ERROR = "You cannot generate Final Bill, as some of "
    		+ "the Diagnostic Reports are not Completed"; 
    public static final String REPORT_PENDING_FINAL_BILL_INITIATE_ERROR = "You cannot initiate Final Bill, as some of "
    		+ "the Diagnostic Reports are not Completed"; 
    public static final String FINAL_BILL_GENERATE_ERROR_OPEN_INQUIRY = "You cannot generate Final Bill, as some "
    		+ "Scheme Inquiry are still Open";
    
    // Ip Registration
    public static final String REPORT_PENDING_DISCHARGE_INITITATE_ERROR = "You cannot initiate Discharge, as some of "
    		+ "the Diagnostic Reports are not Completed"; 
    public static final String OPEN_INQUIRY_DISCHARGE_INITITATE_ERROR = "You cannot initiate Discharge, as some of "
    		+ "the Scheme/Insurance Inquiry are not Closed"; 
    //procedure
    public static final String NO_PROCEDURE_FOUND = "No Procedure Found For patient's Last Open Visit";
	public static final String NO_TREATMENT_FOUND = "No TreatMent Found For Given Visit Of Patient";
	public static final String NO_MEDICINE_FOUND_IN_TREATMENT = "No Medicine Found In Patient's Current Treatment Sheet";
	
	// Patient Concession approval 
	public static final String CONCESSION_APPROVED_SUC = "Patient Concession Approved Successfully";
	public static final String EXPENSE_VALIDATION_FAILED = "Expense Validation Failed!, Either BillId or VisitId Required";
	public static final String BILL_NOT_FOUND = "Bill Not Found For Given Patient, Please Create Visit";
	public static final String BED_CATEGORY_UPDATE_FAILED = "You Can not update Bed Categroy as bill is closed for given visit";
	public static final String BED_CATEGORY_UPDATE_SUC = "Bed Categroy updated successfully";
	
	public static final String SCHEME_EXIST_ERROR = "Scheme Already Applied To Patient";
	public static final String SCHEME_PRIORITY_EXIST_ERROR = "Scheme Priority Already Exists.";
	public static final String INSURANCE_EXIST_ERROR = "Insurance Already Applied To Patient";
	public static final String INSURANCE_PRIORITY_EXIST_ERROR = "Insurance Priority Already Exists.";
	
	//cancel discharge error
	public static final String CANCEL_DISCHARGE_IP_NOT_FOUND_ERROR = "Ip registration Not exist for bill";
	public static final String ALREADY_CANCEL_DISCHARGE_ERROR = "Ip registration already "
			+ "cancelled, please approve workflow";
	public static final String CANCEL_DISCHARGE_PATIENT_DEAD_ERROR = "Discharge can not cancelled for dead patient";
	public static final String CANCEL_DISCHARGE_IP_OPEN_ERROR = "Discharge can not cancelled because it is not confirmed";
	public static final String CANCEL_DISCHARGE_FAIL = "Discharge can not cancelled because it is not discharged.";


	//
	public final static String ACTION_CANCEL = "This action could not be taken";
	
	// hrms
	public static final String INTERVIEW_SCHEDULE_SUCCESS ="Interview Schedule Successfully";
	
	// Employee Requisition
	public static final String EMPLOYEE_REQUISITION_UPDATE_FAIL = "You can not update this Requisition as it is already approved is in Approval Process";
	public static final String EMPLOYEE_REQUISITION_CANCEL_FAIL = "You can not cancel this Requisition as it is already approved or is in Approval Process";
	public static final String EMPLOYEE_REQUISITION_CANCEL_SUC = "Employee Requisition cancelled Successfully";
	public static final String EMPLOYEE_REQUISITION_CLOSE_SUC = "Employee Requisition closed Successfully";
	public static final String EMPLOYEE_REQUISITION_APPROVE_SUC = "Employee Requisition Approved Successfully";
	
	public static final String SHIFT_CHANGE_REQ_INI_SUC = "Shift change request initiated successfully"; 
	public static final String SHIFT_CHANGE_REQ_CAN_SUC = "Shift change request cancelled successfully";
	public static final String SHIFT_CHANGE_REQ_APPROVE_SUC = "Shift change request approved successfully";
	public static final String SHIFT_CHANGE_REQ_ALREADY_APPLIED = "Shift change request Already Applied on this Date Interval";
	
	public static final String REPORT_COMLETE_ERROR = "Report Already Completed";
	public static final String REPORT_RE_OPEN_ERROR_NOT_COMPLETE = "Report can not Re-Open as its not Complete";
	public static final String REPORT_RE_OPEN_SUCC = "Report Re-Opened Successfully";
	public static final String REPORT_COMPLETE_SUC = "Report completed Successfully";
	
	public static final String LEAVE_REQUEST_ALREADY_APPLIED= "Leave request Already Applied on this Date Interval";
	
	public static final String TOUR_REQUEST_ADD_FAIL = "You can not add tour request as your duty is not scheduled";
	public static final String TOUR_REQUEST_UPDATE_FAIL = "You can not update tour request as your duty is not scheduled";
	public static final String TOUR_REQUEST_ALREADY_APPLIED = "Tour request Already Applied on this Date Interval";
	public static final String SHIFT_CHANGE_REQUEST_FAIL = "Shift change request for given employee and shift date is already in progress.";
	
	public static final String PERMISSION_REQUEST_ALREADY_APPLIED = "Permission request Already Applied on this Date Interval";
	
	public static final String CANCEL_EXPENSE_ERROR_BELONG_TO_REPORT = "Can not Cancel Expense as it is belong to Report, Please Cancel Report";
	
	// Booking
	public static final String BOOKING_MESSAGE = "Bed is currently ${status} , Are you sure do you want to continue ?";
	
	public static final String EXPENSE_CANCEL_ERROR_BILL_CLOSED = "Expense can not Cancelled as Bill has been Closed";
	public static final String EXPENSE_RETURN_ERROR_BILL_CLOSED = "Expense can not Return as Bill has been Closed";
	public static final String EXPENSE_CANCEL_SUCCESS = "Expense Cancelled Successfully";
	
	public static final String TEMPLATE_NAME_ALREADY_EXISTS = "Template name already exists.";
	public static final String PO_ITEM_NOT_APPROVED = "Purchase Item Is Not Approved yet, Please approve it.";
	
	
	// HRMS
	public static final String DEFAULT_WORKFLOW_NOT_EXIST = "Default Work Flow does not exist.";
	public static final String EMPLOYEE_REPORTING_HEAD_CANCEL_SUCCESS = "Employee Reporting Head canceled successfully.";

	//Licence
	public static final String WRONG_LICENCE = "Your Licence no is not valid";
	public static final String NOT_ACTIVATED = "Your Licence is not Activated Yet";
	public static final String ALREADYEXISTS = "Your Licence no is Already Exists";
	public static final String ALREADYUSED = "Your Licence no is Already in used";
	
}
