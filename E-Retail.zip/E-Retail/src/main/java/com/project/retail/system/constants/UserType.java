package com.project.retail.system.constants;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public class UserType {

	public enum SubType {
		// Technician Types
		Perfusionist("Perfusionist", "Perfusionist", Type.Technician.getName()), 
		Lab_Technician("Lab_Technician", "Lab Technician", Type.Technician.getName()), 
		Micro_Lab_Technician("Micro_Lab_Technician", "Micro Lab Technician", Type.Technician.getName()),
		Cath_Lab_Technician("Cath_Lab_Technician","Cath Lab Technician", Type.Technician.getName()), 
		Radio_Technician("Radio_Technician", "Radio Technician", Type.Technician.getName()), 
		Echo_Technician("Echo_Technician","Echo Technician", Type.Technician.getName()), 
		ABG_Technician("ABG_Technician", "ABG Technician", Type.Technician.getName()),
		XRay_Technician("X-Ray_Technician","X-Ray Technician", Type.Technician.getName()),
		Haemodialysis_Technician("Haemodialysis_Technician", "Haemodialysis Technician", Type.Technician.getName()),
		CSSD_Technician("CSSD_Technician", "CSSD Technician", Type.Technician.getName()),
	    Anaesthesia_Technician("Anaesthesia_Technician", "Anaesthesia Technician", Type.Technician.getName()),
		
		// Nurse Types
		Sister_In_charge("Sister_In_charge", "Sister-in-charge", Type.Nurse.getName()), 
		Matron_in_charge("Matron_in_charge","Matron-in-charge", Type.Nurse.getName()), 
		Duty_Nurse("Duty_Nurse", "Duty Nurse", Type.Nurse.getName()), 
		Staff_Nurse("Staff_Nurse", "Staff Nurse", Type.Nurse.getName()), 
		Scrub_Nurse("Scrub_Nurse", "Scrub Nurse", Type.Nurse.getName()),
		Floor_Nurse("Floor_Nurse", "Floor Nurse", Type.Nurse.getName()),
		
		// Doctor Types
//		Primary_Operator("Primary_Operator", "Primary Operator", Type.Doctor.getName()),
		Cardiac_Surgeon("Cardiac_Surgeon", "Cardiac Surgeon", Type.Doctor.getName()), 
		General_Surgeon("General_Surgeon","General Surgeon", Type.Doctor.getName()), 
		Anesthetist("Anesthetist", "Anesthetist", Type.Doctor.getName()), 
		Cardiologist("Cardiologist", "Cardiologist", Type.Doctor.getName()), 
		Peadiatrics("Peadiatrics", "Peadiatrics", Type.Doctor.getName()), 
		Pathologist("Pathologist", "Pathologist", Type.Doctor.getName()), 
		Radiologist("Radiologist", "Radiologist", Type.Doctor.getName()), 
		Physiotherapist("Physiotherapist", "Physiotherapist", Type.Doctor.getName()), 
		Medical_Officer("Medical_Officer", "Medical Officer", Type.Doctor.getName()), 
		PGDCC("PGDCC", "PGDCC", Type.Doctor.getName()), 
		DM_Resident_Cardiology("DM_Resident_Cardiology", "DM Resident (Cardiology)",Type.Doctor.getName()), 
		DM_Resident_Cardiac_Anesthesiology("DM_Resident_Cardiac_Anesthesiology","DM Resident (Cardiac Anesthesiology)", Type.Doctor.getName()), 
		Mch_Resident_CVTS("Mch_Resident_CVTS", "Mch Resident (CVTS)", Type.Doctor.getName()),
		Microbiologist("Microbiologist", "Microbiologist", Type.Doctor.getName()),
		Clinical_Cardiologist("Clinical_Cardiologist", "Clinical Cardiologist", Type.Doctor.getName());

		private final String name;
		private final String displayName;
		private final String subType;

		private SubType(String name, String displayName, String subType) {
			this.name = name;
			this.displayName = displayName;
			this.subType = subType;
		}

		public String getName() {
			return name;
		}

		public String getDisplayName() {
			return displayName;
		}

		public String getSubType() {
			return subType;
		}

		@JsonCreator
		public static SubType fromSubType(String type) {
			for (SubType subType : SubType.values()) {
				if (subType.name.equalsIgnoreCase(type)) {
					return subType;
				}
			}
			throw new IllegalArgumentException("Invalid User type code: "
					+ type);
		}
		@Override
		public String toString() {
			return name;
		}
	}

	public enum Type {

		Admin("Admin", "Admin"), 
		Doctor("Doctor", "Doctor"), 
		Nurse("Nurse", "Nurse"), 
		Technician("Technician", "Technician"),  
		Patient_Attendant("Patient_Attendant", "Patient Attendant"), 
		Professor("Professor", "Professor"), 
		Associate_Professor("Associate_Professor", "Associate Professor"), 
		Dm("Dm", "Dm"), 
		Assistant("Assistant", "Assistant"), 
		Consultant("Consultant", "Consultant"), 
		Ward_Account("Ward_Account", "Ward_Account"), 
		Store_User("Store_User", "Store User"), 
		Senior_Resident("Senior_Resident","Senior Resident"), 
		Other("Other", "Other"), 
		Receptionist("Receptionist","Receptionist"),
		Cashier("Cashier", "Cashier"),
		Admission_Desk("Admission_Desk", "Admission Desk");

		private final String name;
		private final String displayName;

		/*
		 * Here SubType is used for Filtering Data according to Type or In
		 * OtherWords we are passing Reference to parent
		 */

		private Type(String name, String displayName) {
			this.name = name;
			this.displayName = displayName;
		}

		@JsonValue
		public String getName() {
			return name;
		}

		public String getDisplayName() {
			return displayName;
		}

		@JsonCreator
		public static Type fromAllType(String type) {
			for (Type allType : Type.values()) {
				if (allType.name.equalsIgnoreCase(type)) {
					return allType;
				}
			}
			throw new IllegalArgumentException("Invalid User type code: "
					+ type);
		}

		@Override
		public String toString() {
			return name;
		}

		// This Methods Give List of SubType based on Type
		public static List<SubType> getSubTypeList(Type type) {
			List<SubType> subTypeLists = new ArrayList<SubType>();
			for (SubType subTypeList : SubType.values()) {
				if (type.getName().equals(subTypeList.getSubType())) {
					subTypeLists.add(subTypeList);
				}
			}
			return subTypeLists;
		}
	}
}
