package com.project.retail.system.oauth2;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.DefaultAuthorizationRequest;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

public final class AuthenticationUtil {

	// Ensures that this class cannot be instantiated
	private AuthenticationUtil() {
	}

	public static void clearAuthentication() {
		SecurityContextHolder.getContext().setAuthentication(null);
	}

	/*public static void configureAuthentication(String userName , String... role) {
		Collection<GrantedAuthority> authorities = AuthorityUtils
				.createAuthorityList(role);
		Authentication authentication = new UsernamePasswordAuthenticationToken(
				userName, "SYSTEM", authorities);
		SecurityContextHolder.getContext().setAuthentication(authentication);
	}

	public static void configureAuthentication(String userName,
			Collection<GrantedAuthority> authorities) {
		Authentication authentication = new UsernamePasswordAuthenticationToken(
				userName, "SYSTEM", authorities);
		SecurityContextHolder.getContext().setAuthentication(authentication);
	}*/
	
	public static void configureAuthenticationWithOAuth2(String token_id,
			Collection<GrantedAuthority> authorities) {
		
		DefaultAuthorizationRequest defaultAuthorizationRequest = new DefaultAuthorizationRequest(
				token_id, new ArrayList<String>());
		defaultAuthorizationRequest.setAuthorities(authorities);
		defaultAuthorizationRequest.setApproved(true);
		
		OAuth2Authentication authentication = new OAuth2Authentication(defaultAuthorizationRequest, null);
		
		SecurityContextHolder.getContext().setAuthentication(authentication);
	}
	
}
