package com.project.retail.system.constants;

public enum StatusConstants {
	success,
	error
}
