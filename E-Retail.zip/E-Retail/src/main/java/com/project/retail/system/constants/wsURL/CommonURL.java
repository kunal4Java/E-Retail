package com.project.retail.system.constants.wsURL;

public class CommonURL {

	public enum UserURL {

		Login("login"), Logout("logout"), Update("update"), Add("add"), Get(
				"get"), List("list"), AutoSearch("autoSearch"), WebLogin(
				"webLogin"), CustomAutoSearch("customAutoSearch"), MapEmployeeToUser(
				"mapEmployeeToUser"), GetUsersOfUnit("getUsersOfUnit"),
				dashbord("dashBord");

		String url;

		UserURL(String url) {
			this.url = url;
		}

		public String get() {
			return "/user/" + url;
		}
	}
	
	public enum CategoryMasterURL {

		Update("update"), Add("add"), Get("get"),GetById("getById");

		String url;

		CategoryMasterURL(String url) {
			this.url = url;
		}

		public String get() {
			return "/categoryMaster/" + url;
		}
	}
	
	public enum ItemMasterURL {

		Update("update"), Add("add"), Get("get"),GetById("getById");

		String url;

		ItemMasterURL(String url) {
			this.url = url;
		}

		public String get() {
			return "/itemMaster/" + url;
		}
	}
	
	public enum TableMasterURL {

		Update("update"), Add("add"), Get("get"),GetById("getById"),
		GetTabelList("getTabelList");

		String url;

		TableMasterURL(String url) {
			this.url = url;
		}

		public String get() {
			return "/tableMaster/" + url;
		}
	}

	public enum ScheduleTableURL {

		Update("update"), AddTable("addTableDetail"), Get("get"),RemoveAllocatedTable("removeAllocatedTable"),
		GetScheduleTablesList("getScheduleTablesList");

		String url;

		ScheduleTableURL(String url) {
			this.url = url;
		}

		public String get() {
			return "/scheduleTableDetail/" + url;
		}
	}
	
	public enum ConfirmOrder {

		Update("updateConfirmOrder"), AddOrder("addConfirmOrder"), Get("getTableDetail");

		String url;

		ConfirmOrder(String url) {
			this.url = url;
		}

		public String get() {
			return "/confirmOrderDetails/" + url;
		}
	}
	
	public enum Stock {

		add("add"), update("update"), Get("get"),Search("search");

		String url;

		Stock(String url) {
			this.url = url;
		}

		public String get() {
			return "/stock/" + url;
		}
	}
	
	public enum RoleURL {
		List("list");

		String url;

		private RoleURL(String url) {
			this.url = url;
		}

		public String get() {
			return "/role/" + url;
		}
	}

	public enum RoleTemplateURL {
		List("list");

		String url;

		private RoleTemplateURL(String url) {
			this.url = url;
		}

		public String get() {
			return "/roleTemplate/" + url;
		}
	}

	public enum ExceptionDetailURL {
		SendMail("sendEmail");

		String url;

		private ExceptionDetailURL(String url) {
			this.url = url;
		}

		public String get() {
			return "/exceptionDetails/" + url;
		}
	}

//	public enum LicenceTemplateURL {
//		Add("add"),Update("update"),Get("get"),Search("searchByFilter"),SearchByStatus("searchByStatus"),ChangeStatus("changeStatus");
//
//		String url;
//
//		private LicenceTemplateURL(String url) {
//			this.url = url;
//		}
//
//		public String get() {
//			return "/licenceTemplate/" + url;
//		}
//	}
	
//	public enum LicenceURL {
//		Add("add"),Update("update"),Get("get"),Search("searchByFilter"),SendMail("sendMail"),ChangeStatus("changeStatus"),LicenceActive("licenceActive"),Renew("renew");
//
//		String url;
//
//		private LicenceURL(String url) {
//			this.url = url;
//		}
//
//		public String get() {
//			return "/licence/" + url;
//		}
//	}
	
//	public enum LicenceHistoryURL {
//		GetLicenceLogs("getLicenceLogs");
//
//		String url;
//
//		private LicenceHistoryURL(String url) {
//			this.url = url;
//		}
//
//		public String get() {
//			return "/licenceLogs/" + url;
//		}
//	}
	

}
