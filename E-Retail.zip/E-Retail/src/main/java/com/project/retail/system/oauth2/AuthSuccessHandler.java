package com.project.retail.system.oauth2;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.stereotype.Component;

@Component
public class AuthSuccessHandler implements
		ApplicationListener<AuthenticationSuccessEvent> {

	Logger logger = Logger.getLogger(getClass());
	
	@Override
	public void onApplicationEvent(AuthenticationSuccessEvent event) {
		logger.info(event.getAuthentication());
	}
}
