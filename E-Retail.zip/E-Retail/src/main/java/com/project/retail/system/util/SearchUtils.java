package com.project.retail.system.util;

public class SearchUtils {

	/**
	 * get Regex compatible string from given string
	 * 
	 * @param input
	 * @return
	 */
	public static String getRegexPatternForSearchWithinText(String input){
		if(input==null){
			return null;
		}
		String tempString = input.replaceAll("[^\\w\\s]","<<$0>>");
		String finalRegexString = tempString.replaceAll("<<", "\\\\").replaceAll(">>", "");
		return searchWithinString(finalRegexString);
	}
	
	public static String getRegexPatternForSearchAtStart(String input){
		if(input==null){
			return null;
		}
		//replace special characters
		String tempString = input.replaceAll("[^\\w\\s]","<<$0>>");
		String finalRegexString = tempString.replaceAll("<<", "\\\\").replaceAll(">>", "");
		return searchAtStart(finalRegexString);
	}
	
	private static String searchAtStart(String regexString){
		return "^" + regexString + ".*";
	}
	
	private static String searchWithinString(String regexString){
		return regexString + ".*";
	}
	
	public static String getRegexCompatibleString(String input) {
		if(input == null){
			return null;
		}
		String tempString = input.replaceAll("[^\\w\\s]","<<$0>>");
		String finalRegexString = tempString.replaceAll("<<", "\\\\").replaceAll(">>", "");
		return finalRegexString;
	}
}
