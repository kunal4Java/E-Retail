package com.project.retail.system.constants;

public enum GetOnScrollType {

	Id_Wise("ID Wise"), Skip_Wise("Skip Wise");
	
	String type;

	GetOnScrollType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}

}
