package com.project.retail.system.service;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.retail.system.constants.AppType;
import com.project.retail.system.constants.GetOnScrollType;
import com.project.retail.system.constants.SessionType;
import com.project.retail.system.dao.UserSessionDetailDao;
import com.project.retail.system.model.Login;
import com.project.retail.system.model.User;
import com.project.retail.system.model.UserSessionDetail;
import com.project.retail.system.oauth2.ClientDetailsService;
import com.project.retail.system.oauth2.UserDetail;

@Service
public class UserSessionDetailService extends RetailService<UserSessionDetail, String>{

	UserSessionDetailDao userSessionDetailDao;
	
	@Autowired
	private ClientDetailsService clientDetailsService;
	
	@Autowired
	public UserSessionDetailService(UserSessionDetailDao userSessionDetailDao) {
		super(userSessionDetailDao);
		this.userSessionDetailDao = userSessionDetailDao;
	}

	public void addSession(Login login, HttpServletRequest request, User user,
			String token_id, SessionType sessionType) {
		
		UserSessionDetail userSessionDetail = new UserSessionDetail();
		userSessionDetail.setIpAddress(request.getRemoteAddr());
		userSessionDetail.setSessionType(sessionType);
		userSessionDetail.setTime(new Date());
		userSessionDetail.setToken_id(token_id);
		userSessionDetail.setUserId(user.getUserId());
		userSessionDetail.setUserMongoId(user.getId());
		if(login != null){
			userSessionDetail.setAppType(login.getAppType());
			userSessionDetail.setMacAddress(login.getMacAddress());
			userSessionDetail.setHostPcName(login.getHostPcName());
		}
		
		save(userSessionDetail);
	}

	public void addLogoutSession(HttpServletRequest request, String token_id) {
		
		UserDetail userDetail = clientDetailsService.getUserDetail(request);
		
		UserSessionDetail userSessionDetail = new UserSessionDetail();
		userSessionDetail.setIpAddress(request.getRemoteAddr());
		userSessionDetail.setSessionType(SessionType.LOGOUT);
		userSessionDetail.setTime(new Date());
		userSessionDetail.setToken_id(token_id);
		userSessionDetail.setUserId(userDetail.getUserId());
		userSessionDetail.setUserMongoId(userDetail.getUserMongoId());
		userSessionDetail.setAppType(userDetail.getAppType());
		userSessionDetail.setMacAddress(userDetail.getMacAddress());
		userSessionDetail.setHostPcName(userDetail.getHostPcName());
		
		save(userSessionDetail);
	}
	
	public AppType getAppTypeFromLoginSession(String token_id, String userMongoId){
		return userSessionDetailDao.getLoginSessionByUserAndTokenId(token_id,
				userMongoId).getAppType();
	}

	public List<UserSessionDetail> search(String userId, Date from, Date to,
			Integer skip, Integer pageSize, String lastId, GetOnScrollType getOnScrollType) {
		return userSessionDetailDao.search(userId, from, to, skip, pageSize, lastId,
				getOnScrollType);
	}

	

	
}
