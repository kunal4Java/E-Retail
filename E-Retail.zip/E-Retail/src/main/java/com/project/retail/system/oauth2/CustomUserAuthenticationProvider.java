package com.project.retail.system.oauth2;

import org.apache.log4j.Logger;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.SpringSecurityMessageSource;
import org.springframework.stereotype.Component;

@Component("customUserAuthenticationProvider")
public class CustomUserAuthenticationProvider  implements AuthenticationProvider {

	Logger logger = Logger.getLogger(CustomUserAuthenticationProvider.class);
	
	protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
	 
	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {

		logger.info("----------CustomUserAuthenticationProvider---------------------authenticate-----------------------------");
		
//		 throw new BadCredentialsException(messages.getMessage(
//                 "AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
//		 
		return authentication;
	}

	public boolean supports(Class<?> arg0) {
		return true;
	}

}
