package com.project.retail.system.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.project.retail.system.oauth2.UserDetail;

public class RequestUtils {

	private static final Logger logger = Logger.getLogger(RequestUtils.class);
	
	public static HttpServletRequest getRequest() {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
		return request;
	}
	public static String getTokenID(){
		return getTokenID(getRequest());
	}
	
	public static String getTokenID(HttpServletRequest request) {

		String token_id = request.getHeader("token_id");

		if (token_id == null) {
			
			HttpSession httpSession = request.getSession();
			if(httpSession != null){
				token_id =  (String) httpSession.getAttribute("token_id");
			}
		}
		
		//logger.info("RequestUtils token_id ---- >> " + token_id);
		
//		if (token_id == null) {
//			token_id = request.getParameter("token_id");
//		}
		
		return token_id;
	}

	public static UserDetail getUserDetail() {
		return getUserDetail(getRequest());
	}
	
	public static UserDetail getUserDetail(HttpServletRequest request) {
		UserDetail userDetail = (UserDetail) request.getAttribute("userDetail");
		return userDetail;
	}

}
