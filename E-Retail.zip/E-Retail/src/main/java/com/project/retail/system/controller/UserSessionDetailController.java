package com.project.retail.system.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.project.retail.system.annotation.RequestBodyParam;
import com.project.retail.system.constants.GetOnScrollType;
import com.project.retail.system.constants.StatusConstants;
import com.project.retail.system.service.UserSessionDetailService;
import com.project.retail.system.util.ResponseGenerator;

@Controller
@RequestMapping("userSession")
public class UserSessionDetailController {

	@Autowired
	private UserSessionDetailService userSessionDetailService;
	
	@RequestMapping(value="search",method=RequestMethod.POST)
	@ResponseBody
	public Object search(@RequestBodyParam String userId, 
			@RequestBodyParam Date from, @RequestBodyParam Date to,
			@RequestBodyParam Integer skip,
			@RequestBodyParam Integer pageSize,
			@RequestBodyParam String lastId,
			@RequestBodyParam GetOnScrollType getOnScrollType){
		return ResponseGenerator.generateResponse(StatusConstants.success, 
				userSessionDetailService.search(userId, from, to, skip, pageSize,
						lastId, getOnScrollType));
	}
}
