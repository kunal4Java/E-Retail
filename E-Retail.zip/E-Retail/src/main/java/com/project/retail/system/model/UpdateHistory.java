package com.project.retail.system.model;

import java.util.Date;

public class UpdateHistory {

	private String updateBy;
	private String updateByUserId;
	private String updateByUserName;
	private Date date = new Date();
	private String action;

	@Deprecated
	public UpdateHistory() {
	}

	@Deprecated
	public UpdateHistory(String updateBy, String updateByUserId, String updateByUserName) {
		this.updateBy = updateBy;
		this.updateByUserId = updateByUserId;
		this.updateByUserName = updateByUserName;
	}
	
	public UpdateHistory(String action) {
		super();
		this.action = action;
	}

	public UpdateHistory(String updateBy, String updateByUserId, String updateByUserName, String action) {
		super();
		this.updateBy = updateBy;
		this.updateByUserId = updateByUserId;
		this.updateByUserName = updateByUserName;
		this.action = action;
	}

	public String getUpdateByUserId() {
		return updateByUserId;
	}

	public void setUpdateByUserId(String updateByUserId) {
		this.updateByUserId = updateByUserId;
	}

	public String getUpdateByUserName() {
		return updateByUserName;
	}

	public void setUpdateByUserName(String updateByUserName) {
		this.updateByUserName = updateByUserName;
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		return "UpdateHistory [updateBy=" + updateBy + ", updateByUserId=" + updateByUserId + ", updateByUserName=" + updateByUserName + ", date="
				+ date + ", action=" + action + "]";
	}
}
