package com.project.retail.system.exception;

import java.nio.file.AccessDeniedException;

import javax.servlet.http.HttpServletRequest;

import org.apache.avalon.framework.ExceptionUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.project.retail.system.constants.StatusConstants;
import com.project.retail.system.service.ExceptionDetailService;
import com.project.retail.system.util.ResponseGenerator;

@ControllerAdvice
public class CustomExceptionHandler {

	Logger logger = Logger.getLogger(getClass());

	@Autowired
	RestResponseEntityExceptionHandler restResponseEntityExceptionHandler;
	
	@Autowired
	ExceptionDetailService exceptionDetailService;

	// @ExceptionHandler(value = AuthException.class)
	// public ResponseEntity<Object> handleAuthException(Exception exception,
	// WebRequest request) {
	//
	// return new
	// ResponseEntity<Object>(ResponseGenerator.generateResponse(StatusConstants.error,
	// exception.getMessage(), null, "750"),
	// HttpStatus.OK);
	// }

	/*
	 * @ExceptionHandler(value = {
	 * org.springframework.security.access.AccessDeniedException.class,
	 * AuthenticationCredentialsNotFoundException.class,
	 * AuthenticationException.class }) public ResponseEntity<Object>
	 * AccessDeniedException(Exception exception, WebRequest request,
	 * HttpServletResponse response) { return
	 * restResponseEntityExceptionHandler.
	 * getResponseEntity(HttpStatus.EXPECTATION_FAILED,
	 * HttpStatus.EXPECTATION_FAILED.value(), exception, request); }
	 */

	@ExceptionHandler(value = DataAccessResourceFailureException.class)
	private Object handleDataAccessResourceFailureException(Exception exception, HttpServletRequest request) {
		logger.error("Mongo server Not started, Please Start it", exception);
		return getResponseEntity(HttpStatus.EXPECTATION_FAILED, HttpStatus.EXPECTATION_FAILED.value(), exception, request);
	}

	@ExceptionHandler(value = Exception.class)
	public Object handleException(Exception exception, HttpServletRequest request) {
		return getResponseEntity(HttpStatus.EXPECTATION_FAILED, HttpStatus.EXPECTATION_FAILED.value(), exception, request);
	}

	public Object getResponseEntity(HttpStatus status, int exceptionCode, Exception ex, HttpServletRequest request) {
		
		RestError restError = new RestError(status, status.value(), ex.getMessage(), ExceptionUtil.printStackTrace(ex), "");

		String contentType = request.getContentType();

		

		if (isContentJson(contentType)) {

			if (ex instanceof AuthException) {
				return new ResponseEntity<Object>(ResponseGenerator.generateResponse(StatusConstants.error, ex.getMessage(), null, "750"),
						HttpStatus.OK);
			} else {
				logger.error(ex.getMessage(), ex);
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				return new ResponseEntity<Object>(restError, headers, status);
			}
		} else {

			logger.error(ex.getMessage(), ex);
			if (ex instanceof AuthenticationException || ex instanceof AuthException || ex instanceof AccessDeniedException) {
				return "error/accessdenied";
			} else {
				logger.error(ex.getMessage(), ex);
				request.setAttribute("exception", ex.getMessage());
				request.setAttribute("exceptionStackTrace", ExceptionUtil.printStackTrace(ex));
				request.setAttribute("url", request.getRequestURL());
				String id = exceptionDetailService.addException(ex.getClass().getName(), ex.getMessage(),
						ExceptionUtil.printStackTrace(ex), request.getRequestURL().toString(), 
						request.getRemoteAddr());
				request.setAttribute("id", id);
				return "error/springError";
			}
		}
	}
	
	private boolean isContentJson(String contentType) {
		if (contentType != null) {
			return contentType.startsWith("application/json");
		}
		return false;
	}
}
