package com.project.retail.system.constants;

public enum MasterStatus {

	ACTIVE("Active"), INACTIVE("In-Active"), APPROVED("Approved");
	private final String displayStatus;

	private MasterStatus(String displayStatus) {
		this.displayStatus = displayStatus;
	}

	public String getDisplayStatus() {
		return displayStatus;
	}

	@Override
	public String toString() {
		return displayStatus;
	}
}
