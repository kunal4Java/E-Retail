package com.project.retail.system.oauth2;

import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.DefaultAuthorizationRequest;
import org.springframework.security.oauth2.provider.token.InMemoryTokenStore;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.project.retail.system.exception.AuthException;
import com.project.retail.system.util.RequestUtils;

public class SpringMVCInterceptor extends HandlerInterceptorAdapter {

	private static final Logger logger = Logger.getLogger(SpringMVCInterceptor.class);

	@Autowired
	UserApprovalHandler userApprovalHandler;

	@Autowired
	ClientDetailsService clientDetailsService;

	@Autowired
	InMemoryTokenStore tokenStore;
	
	public boolean checkAuth(HttpServletRequest request){
		
		boolean approved = false;
		
		String token_id = RequestUtils.getTokenID(request);

		if (token_id == null) {
			return approved;
			//throw new AuthException("Your AccessToken is not valid");
		}

		logger.info("TokenID :: " + token_id);
//		logger.info("URL :: --> " + request.getRequestURL());

		
		DefaultAuthorizationRequest defaultAuthorizationRequest = new DefaultAuthorizationRequest(token_id, new ArrayList<String>());

		if (userApprovalHandler.isApproved(defaultAuthorizationRequest, null)) {

			// A token was already granted and is still valid, so this is
			// already approved
			approved = true;
		} else {

			OAuth2AccessToken accessToken = userApprovalHandler.getAccessToken(defaultAuthorizationRequest, null);

			if (accessToken != null && accessToken.isExpired()) {

				tokenStore.removeAccessToken(accessToken);

				clientDetailsService.remove(token_id);

				// logger.info(tokenStore.getAccessTokenCount());
				// Collection<OAuth2AccessToken> accessTokens =
				// tokenStore.findTokensByClientId(token_id);
				// logger.info(accessTokens);

			}
			approved = false;
			//throw new AuthException("AccessToken Expired. So login again");
		}
		
		return approved;
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

		boolean approved = checkAuth(request);
		if(!approved){
			throw new AuthException("Your AccessToken is not valid. So login again");
		}
		
		String token_id = RequestUtils.getTokenID(request);

		ClientDetails ClientDetails = clientDetailsService.getClientDetailsStore()
				.get(token_id);

		Map<String, Object> map = ClientDetails.getAdditionalInformation();

		if (approved) {

			String ipAddress = (String) map.get("ipAddress");

			if (!request.getRemoteAddr().equals(ipAddress)) {
				approved = false;
				throw new AuthException("Your AccessToken is not valid");
			}
		}

		UserDetail userDetail = (UserDetail) map.get("userDetail");
		request.setAttribute("userDetail", userDetail);

		// set OAuth2Authentication object in SecurityContextHolder For Security
		SecurityContextHolder.setContext(userDetail.getSecurityContext());
		
		//logger.info(" -*-------------------" + SecurityContextHolder.getContext());
		 
		return approved;
	}

}
