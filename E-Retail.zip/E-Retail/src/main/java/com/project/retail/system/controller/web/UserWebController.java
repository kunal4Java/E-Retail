package com.project.retail.system.controller.web;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.project.retail.system.controller.UserController;
import com.project.retail.system.oauth2.SpringMVCInterceptor;
import com.project.retail.system.service.UserTypeMasterService;

@Controller
@RequestMapping("user")
public class UserWebController {

	private static final Logger logger = Logger.getLogger(UserWebController.class);
	@Autowired
	UserTypeMasterService userTypeMasterService;

	@Autowired
	UserController userController;
	
	@Autowired
	SpringMVCInterceptor springMVCInterceptor;
	
	
	@RequestMapping(value = "login", method = RequestMethod.GET)
	public String login(HttpServletRequest request) {
		logger.info("in login page");
		
		if(springMVCInterceptor.checkAuth(request)){
			return "redirect:/user/welcome";
		}
		return "user/login";
	}

	@RequestMapping(value = "logout", method = RequestMethod.GET)
	public String logout(HttpServletRequest request) {
		userController.logout(request);
		return "redirect:/user/login";
	}
	
	@RequestMapping(value = "dashBord", method = RequestMethod.GET)
	public String dashBord(HttpServletRequest request) {
		return "dashboard";
	}
}
