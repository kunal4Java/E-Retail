package com.project.retail.system.exception;

import javax.servlet.http.HttpServletRequest;

import org.apache.avalon.framework.ExceptionUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.TypeMismatchException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException;

@ControllerAdvice
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	Logger logger = Logger.getLogger(this.getClass());

	// 400
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status,
			WebRequest request) {
		return getResponseEntity(status, ExceptionCode.BAD_REQUEST.getCode(), ex, request);
	}

	// 400
	@Override
	protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		return getResponseEntity(status, ExceptionCode.BAD_REQUEST.getCode(), ex, request);
	}

	// 400
	@Override
	protected ResponseEntity<Object> handleTypeMismatch(TypeMismatchException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		// TODO Auto-generated method stub
		return getResponseEntity(status, ExceptionCode.BAD_REQUEST.getCode(), ex, request);
	}

	// 404
	@Override
	protected ResponseEntity<Object> handleNoSuchRequestHandlingMethod(NoSuchRequestHandlingMethodException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		// TODO Auto-generated method stub
		return getResponseEntity(status, ExceptionCode.NOT_FOUND.getCode(), ex, request);
	}

	// 405
	@Override
	protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		// TODO Auto-generated method stub
		return getResponseEntity(status, ExceptionCode.METHOD_NOT_ALLOWED.getCode(), ex, request);
	}

	// 406
	@Override
	protected ResponseEntity<Object> handleHttpMediaTypeNotAcceptable(HttpMediaTypeNotAcceptableException ex, HttpHeaders headers, HttpStatus status,
			WebRequest request) {
		// TODO Auto-generated method stub
		return getResponseEntity(status, ExceptionCode.NOT_ACCEPTABLE.getCode(), ex, request);
	}

	// 415
	@Override
	protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex, HttpHeaders headers, HttpStatus status,
			WebRequest request) {
		// TODO Auto-generated method stub
		return getResponseEntity(status, ExceptionCode.UNSUPPORTED_MEDIA_TYPE.getCode(), ex, request);
	}

	private ResponseEntity<Object> getResponseEntity(HttpStatus status, int exceptionCode, Exception ex, WebRequest request) {
		
		RestError restError = new RestError(status, status.value(), ex.getMessage(), ExceptionUtil.printStackTrace(ex), "");

		String contentType = ((HttpServletRequest)request).getContentType();
		
		logger.error(ex.getMessage(), ex);

		if (isContentJson(contentType)) {
			HttpHeaders headers=  new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			return handleExceptionInternal(ex, restError, headers, status, request);
		} else {
			HttpHeaders headers=  new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			return handleExceptionInternal(ex, restError, headers, status, request);
		}
	}
	
	private boolean isContentJson(String contentType) {
		if (contentType != null) {
			return contentType.startsWith("application/json");
		}
		return false;
	}

}
