package com.project.retail.system.model.Response;

import java.util.Date;

public class LoginInfo {

	private UserDetail userDetail;
	private Date serverDate;

	public LoginInfo(UserDetail userDetail) {
		super();
		this.userDetail = userDetail;
		serverDate = new Date();
	}

	public UserDetail getUserDetail() {
		return userDetail;
	}

	public void setUserDetail(UserDetail userDetail) {
		this.userDetail = userDetail;
	}

	public Date getServerDate() {
		return serverDate;
	}

	public void setServerDate(Date serverDate) {
		this.serverDate = serverDate;
	}

	@Override
	public String toString() {
		return "LoginInfo [userDetail=" + userDetail + ", serverDate="
				+ serverDate + "]";
	}

}
