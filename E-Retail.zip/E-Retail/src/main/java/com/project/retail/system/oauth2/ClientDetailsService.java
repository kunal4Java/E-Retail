package com.project.retail.system.oauth2;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.oauth2.provider.BaseClientDetails;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.InMemoryClientDetailsService;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.project.retail.system.constants.AppType;
import com.project.retail.system.constants.LoginType;
import com.project.retail.system.util.RequestUtils;

@Component
public class ClientDetailsService extends InMemoryClientDetailsService {

	Logger logger = Logger.getLogger(getClass());
	
	public ClientDetailsService() {
		setClientDetailsStore(new HashMap<String, BaseClientDetails>());
	}
	
	public void add(LoginType loginType , String token_id, String ipAddress, String userMongoId, 
			String displayName, String userId,
			AppType appType, String macAddress, String hostPcName, SecurityContext securityContext) {
		
		Map<String, BaseClientDetails> map = (Map<String, BaseClientDetails>) getClientDetailsStore();
		BaseClientDetails trains = new BaseClientDetails();
		trains.setClientId(token_id);
		trains.setClientSecret("trains-client-secret");

		trains.addAdditionalInformation("id", userMongoId);
		trains.addAdditionalInformation("ipAddress", ipAddress);

		// trains.setAccessTokenValiditySeconds(20);

		// store UserDetail in this
		UserDetail userDetail = new UserDetail();
		userDetail.setLoginType(loginType);
		userDetail.setUserMongoId(userMongoId);
		userDetail.setToken_id(token_id);
		userDetail.setDisplayUserName(displayName);
		userDetail.setUserId(userId);
		//userDetail.setEmployeeId(employeeId);
//		userDetail.setUserType(userType);
//		userDetail.setSubType(subType);
		userDetail.setAppType(appType);
		userDetail.setMacAddress(macAddress);
		userDetail.setHostPcName(hostPcName);
		userDetail.setSecurityContext(securityContext);
		
		trains.addAdditionalInformation("userDetail", userDetail);

		map.put(token_id, trains);
	}

	public void remove(String name) {
		Map<String, BaseClientDetails> map = (Map<String, BaseClientDetails>) getClientDetailsStore();
		map.remove(name);
	}

	public UserDetail getUserDetail(String token_id) {

		if (token_id == null) {
			return null;
		}
		ClientDetails clientDetails = getClientDetailsStore().get(token_id);
		if (clientDetails == null) {
			return null;
		}
		Map<String, Object> map = clientDetails.getAdditionalInformation();

		return (UserDetail) map.get("userDetail");
	}

	public UserDetail getUserDetail(HttpServletRequest request) {
		String token_id = getTokenID(request);
		return getUserDetail(token_id);
	}

	public UserDetail getUserDetail() {
		String token_id = getTokenID();
		return getUserDetail(token_id);
	}

	private String getTokenID() {
		
		String token_id = null;
		try {
			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
			token_id = RequestUtils.getTokenID(request);
		} catch (Exception e) {
//			logger.info(e.getClass().getSimpleName() + " Occured During Get request "
//					+ "From RequestContextHolder, Request was Generated from System");
//			logger.error(e.getMessage(), e);
		}
		return token_id;
	}

	private String getTokenID(HttpServletRequest request) {
		String token_id = RequestUtils.getTokenID(request);
		return token_id;
	}
}
