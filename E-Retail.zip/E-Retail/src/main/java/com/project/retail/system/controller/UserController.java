package com.project.retail.system.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.DefaultAuthorizationRequest;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.InMemoryTokenStore;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.project.retail.system.annotation.RequestBodyParam;
import com.project.retail.system.constants.AppType;
import com.project.retail.system.constants.GetOnScrollType;
import com.project.retail.system.constants.LoginType;
import com.project.retail.system.constants.MessageConstants;
import com.project.retail.system.constants.MessageConstants.UserMessagesEnum;
import com.project.retail.system.constants.SessionType;
import com.project.retail.system.constants.SettingsConstants;
import com.project.retail.system.constants.StatusConstants;
import com.project.retail.system.encyption.MD5Encryption;
import com.project.retail.system.model.ClientAppVersion;
import com.project.retail.system.model.Login;
import com.project.retail.system.model.SearchCriteria;
import com.project.retail.system.model.User;
import com.project.retail.system.model.Response.LoginInfo;
import com.project.retail.system.model.Response.ResponseBean;
import com.project.retail.system.model.Response.UserDetail;
import com.project.retail.system.model.Response.UserTypeModel;
import com.project.retail.system.oauth2.ClientDetailsService;
import com.project.retail.system.oauth2.UserApprovalHandler;
import com.project.retail.system.service.ClientAppVersionService;
import com.project.retail.system.service.UserService;
import com.project.retail.system.service.UserSessionDetailService;
import com.project.retail.system.util.RequestUtils;
import com.project.retail.system.util.ResponseGenerator;

@Controller
@RequestMapping("user")
public class UserController {

	private static final Logger logger = Logger.getLogger(UserController.class);

	@Autowired
	DefaultTokenServices tokenServices;

	@Autowired
	ClientDetailsService clientDetailsService;

	@Autowired
	InMemoryTokenStore tokenStore;

	@Autowired
	UserApprovalHandler userApprovalHandler;

	@Autowired
	private UserService userService;

	@Autowired
	private ClientAppVersionService clientAppVersionService;

	@Autowired
	private UserSessionDetailService userSessionDetailService;

	/**
	 * Login with different type of application eg. :-
	 * <ul>
	 * <li>JavaFX</li>
	 * <li>Android</li>
	 * <li>IPhone
	 * <li>
	 * <ul>
	 * if appType is all then login will be done with out version check
	 * 
	 * @param login
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "login", method = RequestMethod.POST)
	@ResponseBody
	public Object login(@RequestBody Login login, HttpServletRequest request,
			HttpServletResponse response) {

		/*ClientAppVersion clientAppVersion = clientAppVersionService.getVersion(
				login.getAppVersion(), login.getAppType());

		if (clientAppVersion == null) {
			return ResponseGenerator.generateResponse(StatusConstants.error,
					MessageConstants.VERSION_ERROR, null, "751");
		}*/

		User user = userService.checkUser(login.getUserId(),
				login.getPassword());

		if (user == null) {
			return ResponseGenerator.generateResponse(StatusConstants.error,
					MessageConstants.LOGIN_FAIL);
		} else if (!user.getStatus()) {
			return ResponseGenerator.generateResponse(StatusConstants.error,
					MessageConstants.INACTIVE_USER);
		}
		return userLogin(login, request, user);
	}

	/**
	 * webLogin
	 * 
	 * @param login
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "webLogin", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean webLogin(@RequestBody Login login,
			HttpServletRequest request, HttpServletResponse response) {
		User user = userService.checkUser(login.getUserId(),
				login.getPassword());

		if (user == null) {
			return ResponseGenerator.generateResponse(StatusConstants.error,
					MessageConstants.LOGIN_FAIL);
		} else if (!user.getStatus()) {
			return ResponseGenerator.generateResponse(StatusConstants.error,
					MessageConstants.INACTIVE_USER);
		} 
		login.setAppType(AppType.Webbrowser);

		return userLogin(login, request, user);
	}

	/**
	 * It checks user exist or not by matching userId and password & It generate
	 * token_id user
	 * 
	 * @param login
	 * @param request
	 * @param response
	 * @return loginInfo
	 */
	private ResponseBean userLogin(Login login, HttpServletRequest request,
			User user) {

		String token_id = UUID.randomUUID().toString();
		String ipAddress = request.getRemoteAddr();

		logger.info(ipAddress);

		ArrayList<GrantedAuthority> roleList = new ArrayList<GrantedAuthority>();

		DefaultAuthorizationRequest defaultAuthorizationRequest = new DefaultAuthorizationRequest(
				token_id, new ArrayList<String>());
		defaultAuthorizationRequest.setAuthorities(roleList);
		defaultAuthorizationRequest.setApproved(true);
		OAuth2Authentication oAuth2Authentication = new OAuth2Authentication(
				defaultAuthorizationRequest, null);

		userSessionDetailService.addSession(login, request, user, token_id,
				SessionType.LOGIN);

		if (login.getAppType() == AppType.Webbrowser) {

			HttpSession httpSession = request.getSession(true);
			httpSession.setAttribute("token_id", token_id);
		}

		// Authenticate the user
		SecurityContext securityContext = SecurityContextHolder.getContext();
		securityContext.setAuthentication(oAuth2Authentication);

		clientDetailsService
				.add(LoginType.USER, token_id, ipAddress, user.getId(),
						user.getDisplayName(), user.getUserId(),
						login.getAppType(), login.getMacAddress(),
						login.getHostPcName(), securityContext);

		tokenServices.createAccessToken(oAuth2Authentication);

		UserDetail detail = new UserDetail(user.getId(), user.getDisplayName(),
				user.getUserId(), token_id);
		LoginInfo loginInfo = new LoginInfo(detail);

		return ResponseGenerator.generateResponse(StatusConstants.success,
				MessageConstants.LOGIN_SUC, loginInfo);
	}

	@RequestMapping(value = "checkLogin", method = RequestMethod.POST)
	@ResponseBody
	public Object checkLogin(@RequestBody User user, HttpServletRequest request) {

		logger.info(user);

		User user1 = userService
				.checkUser(user.getUserId(), user.getPassword());

		if (user1 == null) {
			return ResponseGenerator.generateResponse(StatusConstants.error,
					MessageConstants.LOGIN_FAIL);
		}

		UserDetail detail = new UserDetail(user1.getId(),
				user1.getDisplayName(), user1.getUserId(),
				null);

		// LoginInfo loginInfo = new LoginInfo(detail, null);

		userSessionDetailService.addSession(null, request, user, null,
				SessionType.VULNERABLE_LOGIN);

		return ResponseGenerator.generateResponse(StatusConstants.success,
				MessageConstants.LOGIN_SUC, detail);
	}

	/**
	 * Logout User, it removes the token_id.
	 * 
	 * @param request
	 * @return message
	 */
	@RequestMapping(value = "logout", method = RequestMethod.POST)
	@ResponseBody
	public Object logout(HttpServletRequest request) {

		String token_id = RequestUtils.getTokenID(request);

		userSessionDetailService.addLogoutSession(request, token_id);

		Collection<OAuth2AccessToken> accessTokens = tokenStore
				.findTokensByClientId(token_id);

		logger.info(accessTokens);

		if (accessTokens.size() > 0) {
			tokenStore.removeAccessToken((OAuth2AccessToken) (accessTokens
					.toArray())[0]);
		}

		clientDetailsService.remove(token_id);

		HttpSession httpSession = request.getSession();
		if (httpSession != null) {
			httpSession.invalidate();
		}

		return ResponseGenerator.generateResponse(StatusConstants.success,
				MessageConstants.LOGOUT_SUC);
	}

	/**
	 * add User
	 * 
	 * @param user
	 * @return message
	 */
	@RequestMapping(value = "add", method = RequestMethod.POST)
	public @ResponseBody
	Object createUser(@RequestBody User user) {
		if (userService.checkDuplicateUserId(user.getUserId())) {
			
			String encryptedPassword = MD5Encryption
					.encrypt(user.getPassword());
			user.setPassword(encryptedPassword);
			user.setStatus(true);
			user.setCreatedDate(new Date());
			userService.save(user,"Add New User");
			return ResponseGenerator.generateResponse(StatusConstants.success,
					UserMessagesEnum.ADD_SUCCESS.message("User"));
		} else {
			return ResponseGenerator.generateResponse(StatusConstants.error,
					UserMessagesEnum.UNIQUE.message("UserId"));
		}
	}

	/**
	 * get user by id
	 * 
	 * @param id
	 * @return user
	 */
	@RequestMapping(value = "get", method = RequestMethod.POST)
	@ResponseBody
	public Object getUserById(@RequestBodyParam String id) {

		User user = (User) userService.findOne(id);
		return ResponseGenerator
				.generateResponse(StatusConstants.success, user);
	}

	/**
	 * update user
	 * 
	 * @param user
	 * @return message
	 */
	@RequestMapping(value = "update", method = RequestMethod.POST)
	@ResponseBody
	public Object update(@RequestBody User user) {
		logger.info("update user   " + user.toString());
		// if(user.getCustomRole() != null){
		logger.info("Custom Roles Are Applied...!!!");
		// }
		userService.updateWithNull(user, "Set Role");

		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("User"));
	}

	/**
	 * update user without role
	 * 
	 * @param user
	 * @return message
	 */

	@RequestMapping(value = "updateByUser", method = RequestMethod.POST)
	@ResponseBody
	public Object updateByUser(@RequestBody User user) {
		userService.update(user);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("User"));
	}

	/**
	 * Return first 100 users list according to search Criteria if given and
	 * sort by userId.
	 * 
	 * @param searchCriteria
	 * @return List<User>
	 */
	@RequestMapping(value = "list", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean getAllUsersBySearchCriteria(
			@RequestBodyParam SearchCriteria searchCriteria,
			@RequestBodyParam List<String> roleAccessList,
			@RequestBodyParam Integer pageSize,
			@RequestBodyParam String lastId, @RequestBodyParam Integer skip,
			@RequestBodyParam GetOnScrollType getOnScrollType) {

		logger.info("getting all users.......");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				userService.searchUser(searchCriteria, roleAccessList,
						pageSize, lastId, skip, getOnScrollType));

	}

	/**
	 * Search Active users whose status is true
	 * 
	 * @param searchCriteria
	 * @return List<user> (only specific details of User displayName, userId,
	 *         userType)
	 */

	@RequestMapping(value = "searchActiveUsers", method = RequestMethod.POST)
	@ResponseBody
	public Object searchActiveUsers(
			@RequestBody(required = false) SearchCriteria searchCriteria) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				userService.searchActiveUsers(searchCriteria));
	}

	@RequestMapping(value = "autoSearch", method = RequestMethod.POST)
	@ResponseBody
	public Object autoSearch(@RequestBody SearchCriteria searchCriteria)
			throws Exception {

		return ResponseGenerator.generateResponse(StatusConstants.success,
				userService.autoSearchUser(searchCriteria));
	}

	/**
	 * @return List of users with their displayNames
	 */
	@RequestMapping(value = "getUsersDisplayName", method = RequestMethod.POST)
	@ResponseBody
	public Object getAllUsersDisplayName() {

		return ResponseGenerator.generateResponse(StatusConstants.success,
				userService.getAllUsersDisplayName());
	}

	/**
	 * Find user's displayNames by given list of user's id
	 * 
	 * @return List<User> (users with their id and displayNames)
	 */
	@RequestMapping(value = "getUserNameById", method = RequestMethod.POST)
	@ResponseBody
	public Object getUserNameById(@RequestBody List<String> listofHistoryById) {
		List<User> result = userService.getUserNameById(listofHistoryById);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				result);
	}

	/**
	 * Find user's displayNames by given list of user's id
	 * 
	 * @return List<User> (users with their id and displayNames)
	 */
	@RequestMapping(value = "getSingleUserNameById", method = RequestMethod.POST)
	@ResponseBody
	public Object getSingleUserNameById(@RequestBodyParam String userId) {
		User user = userService.findOneSmallUserById(userId);
		return ResponseGenerator
				.generateResponse(StatusConstants.success, user);
	}

	/**
	 * change password of user using id match id & password of user
	 * 
	 * @param user
	 * @return
	 */
	@RequestMapping("changePassword")
	@ResponseBody
	public Object changePassword(@RequestBody User user) {
		logger.info(user);

		if (userService.changePassword(user)) {
			return ResponseGenerator.generateResponse(StatusConstants.success,
					MessageConstants.PASSWORD_CHANGE_SUC);
		} else {
			return ResponseGenerator.generateResponse(StatusConstants.error,
					MessageConstants.USER_NOT_FOUND);
		}

	}

	/**
	 * Change password of User if user has access Role of Change Password
	 * 
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "changePasswordByUser", method = RequestMethod.POST)
	@ResponseBody
	public Object changePasswordByUser(@RequestBody User user) {
		logger.info(user);
		userService.changePasswordByUser(user);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				MessageConstants.PASSWORD_CHANGE_SUC);
	}

	/**
	 * upload Photo of user save it with id of user under userPhoto folder
	 * 
	 * @param userPhoto
	 * @param id
	 * @param request
	 * @return
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	@RequestMapping(value = "uploadPhoto", method = RequestMethod.POST)
	@ResponseBody
	public Object uploadPhoto(
			@ModelAttribute("userPhoto") MultipartFile userPhoto,
			@ModelAttribute("id") String id, HttpServletRequest request)
			throws IllegalStateException, IOException {
		logger.info("-------------id------>" + id);
		logger.info(userPhoto.getOriginalFilename());

		userPhoto.transferTo(new File(SettingsConstants.USER_PHOTO_PATH
				+ File.separator + id + ".jpg"));
		return ResponseGenerator.generateResponse(StatusConstants.success,
				MessageConstants.USER_PHOTO_UPLOAD_SUC);
	}

	/**
	 * get photo of user using id if no photo available for id then return
	 * default photo
	 * 
	 * @param id
	 * @param request
	 * @param response
	 * @return byte array of image
	 * @throws IOException
	 */
	@RequestMapping(value = "getPhoto/{id}")
	@ResponseBody
	public Object getPhoto(@PathVariable("id") String id,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {

		File imageFile = new File(SettingsConstants.USER_PHOTO_PATH
				+ File.separator + id + ".jpg");

		if (!imageFile.exists()) {
			imageFile = new File(SettingsConstants.defaultUserPhotoPath);
		}
		logger.info("imageFile.getAbsolutePath():-- "
				+ imageFile.getAbsolutePath());
		logger.info("imageFile.getCanonicalPath():-- "
				+ imageFile.getCanonicalPath());
		logger.info("imageFile.getPath():-- " + imageFile.getPath());

		byte[] bytes = FileCopyUtils.copyToByteArray(imageFile);

		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.add("Content-Disposition", "inline; filename=\"" + id
				+ ".jpg\"");
		responseHeaders.setContentType(MediaType.IMAGE_JPEG);
		responseHeaders.setContentLength(bytes.length);

		return new ResponseEntity<byte[]>(bytes, responseHeaders, HttpStatus.OK);
	}

	/**
	 * Find users with given userType and subType whose status is true
	 * 
	 * @param userTypeModel
	 * @return List<User> (Only Specific Detail userId,userType, subType,
	 *         displayName, status )
	 */
	@RequestMapping(value = "smallListBySingleType", method = RequestMethod.POST)
	@ResponseBody
	public Object smallListBySingleType(@RequestBody UserTypeModel userTypeModel) {
		logger.info("userTypeModel:-- " + userTypeModel);
		List<User> result = userService.smallListBySingleType(userTypeModel);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				result);
	}

	/**
	 * Find users with multiple userTypes and its subTypes whose status is true
	 * 
	 * @param userTypeModels
	 * @return List<User> (Only Specific Detail userId,userType, subType,
	 *         displayName, status )
	 */
	@RequestMapping(value = "smallListByMultipleType", method = RequestMethod.POST)
	@ResponseBody
	public Object smallListByMultipleType(
			@RequestBody List<UserTypeModel> userTypeModels) {
		logger.info("userTypeModels:-- " + userTypeModels);
		List<User> result = userService.smallListByMultipleType(userTypeModels);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				result);
	}

	/**
	 * custom autoSearch
	 * 
	 * @param searchCriteria
	 * @param userType
	 * @param userId
	 * @return List<User> (User whose status is true)
	 */
	@RequestMapping(value = "customAutoSearch", method = RequestMethod.POST)
	@ResponseBody
	public Object customAutoSearch(
			@RequestBodyParam SearchCriteria searchCriteria,
			@RequestBodyParam String userType, @RequestBodyParam String userId,
			@RequestBodyParam String accessName,
			@RequestBodyParam List<String> subTypes,
			@RequestBodyParam String displayName) {
		List<User> users = userService.customAutoSearch(searchCriteria,
				userType, userId, accessName, subTypes, displayName);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				users);
	}

	@RequestMapping(value = "getActiveUsersByRole", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean getActiveUsersByRole(
			@RequestBodyParam List<String> roleAccessList) {
		List<User> result = userService.getActiveUserByRole(roleAccessList);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				result);
	}

	@RequestMapping(value = "getActiveUsersByAnyRole", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean getActiveUsersByAnyRole(
			@RequestBodyParam List<String> roleAccessList) {
		List<User> result = userService.getActiveUsersByAnyRole(roleAccessList);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				result);
	}
	
}
