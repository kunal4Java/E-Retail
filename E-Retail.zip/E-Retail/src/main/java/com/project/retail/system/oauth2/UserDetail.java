package com.project.retail.system.oauth2;

import org.springframework.security.core.context.SecurityContext;

import com.project.retail.system.constants.AppType;
import com.project.retail.system.constants.LoginType;

public class UserDetail {

	private LoginType loginType;
	private String userMongoId;
	private String token_id;
	private String userId;
	private String displayUserName;
	private String employeeId;
	private String userType;
	private String subType;
	private AppType appType;
	private String macAddress;
	private String hostPcName;
	private SecurityContext securityContext;

	public LoginType getLoginType() {
		return loginType;
	}

	public void setLoginType(LoginType loginType) {
		this.loginType = loginType;
	}

	public String getUserMongoId() {
		return userMongoId;
	}

	public void setUserMongoId(String userMongoId) {
		this.userMongoId = userMongoId;
	}

	public String getToken_id() {
		return token_id;
	}

	public void setToken_id(String token_id) {
		this.token_id = token_id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Deprecated
	public String getUserName() {
		return displayUserName;
	}

	public String getDisplayUserName() {
		return displayUserName;
	}

	public void setDisplayUserName(String displayUserName) {
		this.displayUserName = displayUserName;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getUserType() {
		return userType;
	}

	public String getSubType() {
		return subType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public boolean isEmployee() {
		if (employeeId != null && employeeId != "") {
			return true;
		}
		return false;
	}

	public AppType getAppType() {
		return appType;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public String getHostPcName() {
		return hostPcName;
	}

	public void setAppType(AppType appType) {
		this.appType = appType;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public void setHostPcName(String hostPcName) {
		this.hostPcName = hostPcName;
	}

	public SecurityContext getSecurityContext() {
		return securityContext;
	}

	public void setSecurityContext(SecurityContext securityContext) {
		this.securityContext = securityContext;
	}

	@Override
	public String toString() {
		return "UserDetail [loginType=" + loginType + ", userMongoId="
				+ userMongoId + ", token_id=" + token_id + ", userId=" + userId
				+ ", displayUserName=" + displayUserName + ", employeeId="
				+ employeeId + ", userType=" + userType + ", subType="
				+ subType + ", appType=" + appType + ", macAddress="
				+ macAddress + ", hostPcName=" + hostPcName
				+ ", securityContext=" + securityContext + "]";
	}

}
