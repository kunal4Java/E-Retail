package com.project.retail.system;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.AfterConvertEvent;
import org.springframework.data.mongodb.core.mapping.event.MongoMappingEvent;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.project.retail.system.annotation.ApplyCustomJoin;
import com.project.retail.system.annotation.CustomJoin;
import com.project.retail.system.annotation.CustomJoinFindAll;
import com.project.retail.system.annotation.CustomJoinListToList;
import com.project.retail.system.annotation.CustomJoinListToMap;
import com.project.retail.system.model.AbstractDocument;

@SuppressWarnings("rawtypes")
@Component
public class RetailEventListener extends AbstractMongoEventListener {

	@Autowired
	MongoTemplate mongoTemplate;


	@Override
	public void onApplicationEvent(MongoMappingEvent event) {
		try {
			if (event instanceof AfterConvertEvent) {

				Class<? extends Object> classtype = event.getSource()
						.getClass();

				Object classtypeobj = event.getSource();

				Field allField[] = classtype.getDeclaredFields();

				fillObjectByAnnotation(allField, classtype, classtypeobj);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void fillObjectByAnnotation(Field allField[],
			Class<? extends Object> classtype, Object classtypeobj)
			throws Exception {

		for (Field field : allField) {

			if (field.isAnnotationPresent(CustomJoin.class)) {
				findReference(classtype, classtypeobj, field);

			} else if (field.isAnnotationPresent(CustomJoinFindAll.class)) {
				findAllReference(classtype, classtypeobj, field);

			} else if (field.isAnnotationPresent(CustomJoinListToList.class)) {
				findListReference(classtype, classtypeobj, field);

			} else if (field.isAnnotationPresent(CustomJoinListToMap.class)) {
				CustomJoinListToMap(classtype, classtypeobj, field);

			} else if (field.isAnnotationPresent(ApplyCustomJoin.class)) {

				if (field.getGenericType() instanceof ParameterizedType) {

					ParameterizedType ptype = (ParameterizedType) field
							.getGenericType();

					if (ptype.getRawType().equals(List.class)) {

						List<?> objects = (List<?>) (new PropertyDescriptor(
								field.getName(), classtype).getReadMethod()
								.invoke(classtypeobj));

						if (objects != null) {

							for (Object innerobject : objects) {

								Class<?> innerClass = (Class<?>) ptype
										.getActualTypeArguments()[0];

								fillObjectByAnnotation(
										innerClass.getDeclaredFields(),
										innerClass, innerobject);
							}
						}
					}
				} else {

					Object innerobject = new PropertyDescriptor(
							field.getName(), classtype).getReadMethod().invoke(
							classtypeobj);
					if (innerobject != null) {
						Class<?> innnerclasstype = innerobject.getClass();

						fillObjectByAnnotation(
								innnerclasstype.getDeclaredFields(),
								innnerclasstype, innerobject);
					}
				}
			}
		}
	}

	/**
	 * Find join collection data
	 * 
	 * @param classtype
	 *            : Main Generic Class
	 * @param classtypeobj
	 *            : Sub Reference Class
	 * @param field
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws IntrospectionException
	 */
	void findReference(Class<? extends Object> classtype, Object classtypeobj,
			Field field) throws Exception {

		CustomJoin fields = field.getDeclaredAnnotation(CustomJoin.class);

		String joinId = fields.joinId();
		Object objectjoinId = (new PropertyDescriptor(joinId, classtype)
				.getReadMethod().invoke(classtypeobj));

		if (objectjoinId == null || objectjoinId.toString().isEmpty()) {
			return;
		}

		boolean isInclude = fields.isInclude();
		Query query = new Query();
		
		
		
		if (fields.value().length != 0) {
			String[] excludeFields = fields.value();
			for (String str : excludeFields) {
				if(isInclude){
					query.fields().include(str);
				}else{
					query.fields().exclude(str);
				}
			}
		}

		String joinIdValue = objectjoinId.toString();
		String refId = fields.refId();

		Object joinObject;
		try{
			if (refId.equalsIgnoreCase("_id")) {
				query.addCriteria(Criteria.where("id").is(new ObjectId(joinIdValue)));
			} else {
				String refIdValue = (new PropertyDescriptor(joinId, classtype)
						.getReadMethod().invoke(classtypeobj)).toString();
				query.addCriteria(Criteria.where(refIdValue).is(joinIdValue));
			}
//			logger.info("=== ***** Query Fired throuh Custom Join ***** === For Class==> " 
//						+ field.getType().getSimpleName());
			joinObject = mongoTemplate.findOne(query, field.getType());
		}catch(Exception e){
			joinObject = null;
		}
		
		
		PropertyDescriptor pd = new PropertyDescriptor(field.getName(),
				classtype);
		pd.getWriteMethod().invoke(classtypeobj, joinObject);

	}

	/**
	 * Findall join collection data
	 * 
	 * @param classtype
	 *            : Main Generic Class
	 * @param classtypeobj
	 *            : Sub Reference Class
	 * @param field
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws IntrospectionException
	 */
	void findAllReference(Class<? extends Object> classtype,
			Object classtypeobj, Field field) throws Exception {

		ParameterizedType stringListType = (ParameterizedType) field
				.getGenericType();
		Class<?> actualGericClass = (Class<?>) stringListType
				.getActualTypeArguments()[0];

		CustomJoinFindAll fields = field
				.getDeclaredAnnotation(CustomJoinFindAll.class);

		String joinId = fields.joinId();
		Object objectjoinId = (new PropertyDescriptor(joinId, classtype)
				.getReadMethod().invoke(classtypeobj));

		if (objectjoinId == null) {
			return;
		}

		String refId = fields.refId();
		boolean isInclude = fields.isInclude();

		BasicDBObject exclude = new BasicDBObject();
		if (fields.value().length != 0) {
			String[] excludeFields = fields.value();
			for (String str : excludeFields) {
				exclude.put(str, isInclude);
			}
		}

		String joinIdValue = objectjoinId.toString();

		DBObject query = null;
		if (refId.equalsIgnoreCase("_id")) {

			query = new BasicDBObject("_id", new ObjectId(joinIdValue));
		} else {
			String refIdValue = (new PropertyDescriptor(joinId, classtype)
					.getReadMethod().invoke(classtypeobj)).toString();
			query = new BasicDBObject(refIdValue, joinIdValue);
		}

//		logger.info("=== ***** Query Fired throuh Custom Join ***** === For Class==> " 
//				+ field.getType().getSimpleName());
		DBCursor dbCursor = getDBCollection(actualGericClass).find(query,
				exclude);

		List<Object> list = new ArrayList<Object>();

		while (dbCursor.hasNext()) {
			DBObject dbObject = dbCursor.next();
			Object joinObject = mongoTemplate.getConverter().read(
					actualGericClass, dbObject);
			list.add(joinObject);
		}

		PropertyDescriptor pd = new PropertyDescriptor(field.getName(),
				classtype);
		pd.getWriteMethod().invoke(classtypeobj, list);

	}

	void findListReference(Class<? extends Object> classtype,
			Object classtypeobj, Field field) throws IllegalAccessException,
			IllegalArgumentException, InvocationTargetException,
			IntrospectionException {

		CustomJoinListToList fields = field
				.getDeclaredAnnotation(CustomJoinListToList.class);

		String joinId = fields.joinId();

		List<Object> objects = new ArrayList<>(); // for store Reports

		List<ObjectId> ids = new ArrayList<>(); // store ids

		List<String> objectjoinId = (List<String>) (new PropertyDescriptor(
				joinId, classtype).getReadMethod().invoke(classtypeobj));

		if (objectjoinId == null || objectjoinId.size() == 0 || objectjoinId.toString().isEmpty()) {
			return;
		}

		try{
			for (String string : objectjoinId) {
				ids.add(new ObjectId(string));
			}
		}catch(Exception e){
		}
		

		boolean isInclude = fields.isInclude();

		//BasicDBObject exclude = new BasicDBObject();

		Query query1 = new Query();
		
		if (fields.value().length != 0) {
			String[] excludeFields = fields.value();
			for (String str : excludeFields) {
				//exclude.put(str, isInclude);
				if(isInclude){
					query1.fields().include(str);
				}else{
					query1.fields().exclude(str);
				}
			}
		}

		String refId = fields.refId();

		//DBObject query = null;

		query1.addCriteria(Criteria.where(refId).in(ids));
		
		//query = new BasicDBObject(refId, new BasicDBObject("$in", ids));
		
		
		ParameterizedType ptype = (ParameterizedType) field.getGenericType();

//		DBCursor dbCursor = getDBCollection(
//				(Class<?>) ptype.getActualTypeArguments()[0]).find(query,
//				exclude);
		
		Object joinObject;
		
		try{
//			logger.info("=== ***** Query Fired throuh Custom Join ***** === For Class==> " 
//					+ field.getType().getSimpleName());
			joinObject = mongoTemplate.find(query1, (Class<?>) ptype.getActualTypeArguments()[0]);
		}catch(Exception e){
			joinObject = null;
		}

//		while (dbCursor.hasNext()) {
//			DBObject dbObject = dbCursor.next();
//			Object joinObject = mongoTemplate.getConverter().read(
//					(Class<?>) ptype.getActualTypeArguments()[0], dbObject);
//			objects.add(joinObject);
//		}

		PropertyDescriptor pd = new PropertyDescriptor(field.getName(),
				classtype);
		pd.getWriteMethod().invoke(classtypeobj, joinObject);

	}

	private void CustomJoinListToMap(Class<? extends Object> classtype,
			Object classtypeobj, Field field) throws Exception{

		CustomJoinListToMap fields = field
				.getDeclaredAnnotation(CustomJoinListToMap.class);

		String joinId = fields.joinId();

		Map<String,Object> outputObjects = new HashMap<>(); 

		List<ObjectId> ids = new ArrayList<>(); // store ids

		List<String> objectjoinId = (List<String>) (new PropertyDescriptor(
				joinId, classtype).getReadMethod().invoke(classtypeobj));

		if (objectjoinId == null || objectjoinId.size() == 0 || objectjoinId.toString().isEmpty()) {
			return;
		}

		try{
			for (String string : objectjoinId) {
				ids.add(new ObjectId(string));
			}
		}catch(Exception e){
		}
		
		Query query1 = new Query();
		boolean isInclude = fields.isInclude();

		//BasicDBObject exclude = new BasicDBObject();

		if (fields.value().length != 0) {
			String[] excludeFields = fields.value();
			for (String str : excludeFields) {
				//exclude.put(str, isInclude);
				if(isInclude){
					query1.fields().include(str);
				}else{
					query1.fields().exclude(str);
				}
			}
		}

		String refId = fields.refId();

		//DBObject query = new BasicDBObject(refId, new BasicDBObject("$in", ids));
		query1.addCriteria(Criteria.where(refId).in(ids));

		ParameterizedType ptype = (ParameterizedType) field.getGenericType();
		
//		DBCursor dbCursor = getDBCollection(
//				(Class<?>) ptype.getActualTypeArguments()[1]).find(query,
//				exclude);
		
		List joinObject;
		try{
//			logger.info("=== ***** Query Fired throuh Custom Join ***** === For Class==> " 
//					+ field.getType().getSimpleName());
			joinObject = mongoTemplate.find(query1, (Class<?>) ptype.getActualTypeArguments()[1]);
		}catch(Exception e){
			joinObject = null;
		}
		

//		while (dbCursor.hasNext() {
//			DBObject dbObject = dbCursor.next();
//			Object joinObject = mongoTemplate.getConverter().read(
//					(Class<?>) ptype.getActualTypeArguments()[1], dbObject);
//			
//			outputObjects.put(dbObject.get("_id").toString(), joinObject);
//		}
		
		for (Object object : joinObject) {
			AbstractDocument abstractDocument = (AbstractDocument) object; 
			outputObjects.put(abstractDocument.getId(), object);
		}

		PropertyDescriptor pd = new PropertyDescriptor(field.getName(),
				classtype);
		pd.getWriteMethod().invoke(classtypeobj, outputObjects);
	}

	private DBCollection getDBCollection(Class<?> actualGericClass) {

		Document document = actualGericClass
				.getDeclaredAnnotation(Document.class);
		DBCollection collection = mongoTemplate.getCollection(document
				.collection());
		
		return collection;
	}

}
