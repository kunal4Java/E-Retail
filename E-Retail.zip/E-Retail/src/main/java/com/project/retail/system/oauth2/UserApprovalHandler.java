package com.project.retail.system.oauth2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.AuthorizationRequest;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.approval.TokenServicesUserApprovalHandler;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;

public class UserApprovalHandler extends TokenServicesUserApprovalHandler {

	
	@Autowired
	DefaultTokenServices tokenServices;
	
	@Override
	public AuthorizationRequest updateBeforeApproval(AuthorizationRequest authorizationRequest, Authentication userAuthentication) {
		return super.updateBeforeApproval(authorizationRequest, userAuthentication);
	}

	/**
	 * Allows automatic approval for a white list of clients in the implicit grant case.
	 * 
	 * @param authorizationRequest The authorization request.
	 * @param userAuthentication the current user authentication
	 * 
	 * @return Whether the specified request has been approved by the current user.
	 */
	@Override
	public boolean isApproved(AuthorizationRequest authorizationRequest, Authentication userAuthentication) {
	
		boolean approved = false;
		
		OAuth2Authentication authentication = new OAuth2Authentication(authorizationRequest, userAuthentication);

		OAuth2AccessToken accessToken = tokenServices.getAccessToken(authentication);
		if (accessToken != null && !accessToken.isExpired()) {
			// A token was already granted and is still valid, so this is already approved
			approved = true;
		}
		
		return approved;
	}
	
	public OAuth2AccessToken getAccessToken(AuthorizationRequest authorizationRequest, Authentication userAuthentication) {

		OAuth2Authentication authentication = new OAuth2Authentication(authorizationRequest, userAuthentication);
		OAuth2AccessToken accessToken = tokenServices.getAccessToken(authentication);
		
		return accessToken;
	}
}
