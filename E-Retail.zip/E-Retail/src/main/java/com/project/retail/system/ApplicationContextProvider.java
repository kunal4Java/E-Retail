package com.project.retail.system;

import java.io.File;
import java.nio.file.AccessDeniedException;
import java.util.Set;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.web.context.ConfigurableWebApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.project.retail.system.constants.SettingsConstants;
import com.project.retail.system.oauth2.SessionListener;

//@Component
public class ApplicationContextProvider implements ApplicationContextAware {

	@Value("${saveFolderLocation}")
	private String saveFolderLocation;
	


	@Autowired
	SessionListener sessionListener;

	private static ApplicationContext applicationContext;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

		
		ConfigurableWebApplicationContext context =  (ConfigurableWebApplicationContext) applicationContext;
		
		
		ApplicationContextProvider.applicationContext = applicationContext;

		WebApplicationContext webApplicationContext = (WebApplicationContext) applicationContext;


		SettingsConstants.DOCUMENT_ROOT_PATH = webApplicationContext.getServletContext().getRealPath("");
		/*
		 * List down all requestMapping
		 */
		getRequestMappingUrlFromWAC(webApplicationContext);

		/*
		 * List down all Bean ....
		 */
		getBeanListFromWAC(webApplicationContext);

		try {
			setHmisDataPath();
		} catch (Exception e) {
		}

		webApplicationContext.getServletContext().addListener(sessionListener);
	}

	private void setHmisDataPath() throws Exception {


		File file;

		if (saveFolderLocation.isEmpty()) {
			file = new File(SettingsConstants.DOCUMENT_ROOT_PATH + File.separator + "E-Retail-App-Documents");
		} else {
			file = new File(saveFolderLocation);
		}
		file.mkdirs();
		if (!file.canExecute()) {
			throw new AccessDeniedException(file.getPath() + " :: File can not read and Write...");
		}

		SettingsConstants.setDataPath(file.getPath());
	}

	private void getBeanListFromWAC(WebApplicationContext webApplicationContext) {
		String[] all = webApplicationContext.getBeanDefinitionNames();

		/*
		 * for (String string : all) { logger.info(string); }
		 */
	}

	private void getRequestMappingUrlFromWAC(WebApplicationContext webApplicationContext) {
		RequestMappingHandlerMapping requestMappingHandlerMapping = webApplicationContext.getBean(RequestMappingHandlerMapping.class);

		Set<RequestMappingInfo> rmSet = requestMappingHandlerMapping.getHandlerMethods().keySet();

		/*
		 * for (RequestMappingInfo rm : rmSet) {
		 * logger.info(rm.getPatternsCondition().toString()); }
		 */
	}

	public static Object getBean(String name) {
		return applicationContext.getBean(name);
	}

}
