package com.project.retail.system.service;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.retail.system.constants.GetOnScrollType;
import com.project.retail.system.dao.UserDao;
import com.project.retail.system.model.SearchCriteria;
import com.project.retail.system.model.User;
import com.project.retail.system.model.Response.UserTypeModel;
import com.project.retail.system.util.MongoUtils;

@Service
public class UserService extends RetailService<User, String> {

	UserDao userDao;

	Logger logger = Logger.getLogger(getClass());

	@Autowired
	public UserService(UserDao userDao) {
		super(userDao);
		this.userDao = userDao;
	}

	public User checkUser(String userId, String password) {
		return userDao.checkUser(userId, password);
	}

	public Object autoSearchUser(SearchCriteria searchCriteria)
			throws IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, IntrospectionException {
		return userDao.autoSearchUser(searchCriteria.getKey(),
				searchCriteria.getValue());
	}

	public List<User> searchUser(SearchCriteria searchCriteria,
			List<String> roleAccessList, Integer pageSize, String lastId,
			Integer skip, GetOnScrollType getOnScrollType) {
		return userDao.searchUser(searchCriteria, roleAccessList, pageSize,
				lastId, skip, getOnScrollType);
	}

	public List<User> searchActiveUsers(SearchCriteria searchCriteria) {
		return userDao.searchActiveUsers(searchCriteria);
	}

	public boolean checkDuplicateUserId(String userId) {
		return userDao.checkDuplicateUserId(userId);
	}

	public boolean changePassword(User user) {
		return userDao.changePassword(user);
	}

	public List<User> getSmallListByType(List<String> typeList) {
		return userDao.getSmallListByType(typeList);
	}

	public List<String> getUserIdsByType(List<String> typeList) {
		List<String> userIds = new ArrayList<>();
		List<ObjectId> objectIds = userDao.getUserIdsByType(typeList);
		if (objectIds != null) {
			for (ObjectId id : objectIds) {
				userIds.add(id.toHexString());
			}
		}
		return userIds;
	}

	public void assignRoleToUsers(List<String> userIds, Object role) {
		userDao.assignRoleToUsers(userIds, role);
	}

	public List<User> getAllUsersDisplayName() {
		List<User> users = userDao.getAllUsersDisplayName();
		return users;
	}

	public void changePasswordByUser(User user) {
		userDao.changePasswordByUser(user);
	}

	/**
	 * find users with given Ids
	 * 
	 * @param userIds
	 * @return only specific details(userId, displayName)
	 */
//	public List<User> getSmallListByIds(List<String> userIds) {
//		return userDao.getSmallListByIds(userIds);
//	}

	/**
	 * find Users with Given userType And SubType
	 * 
	 * @param userTypeModel
	 * @return only Specific details(userId, userType, subType, displayName,
	 *         status) of Users
	 */
	public List<User> smallListBySingleType(UserTypeModel userTypeModel) {
		return userDao.smallListBySingleType(userTypeModel);
	}

	/**
	 * fins users with Given userTypes And subTypes
	 * 
	 * @param userTypeModels
	 * @return only Specific details(userId, userType, subType, displayName,
	 *         status) of Users
	 */
	public List<User> smallListByMultipleType(List<UserTypeModel> userTypeModels) {
		return userDao.smallListByMultipleType(userTypeModels);
	}

	public List<User> customAutoSearch(SearchCriteria searchCriteria,
			String userType, String userId, String accessName,
			List<String> subTypes, String displayName) {
		List<User> users = userDao.customAutoSearch(searchCriteria, userType,
				userId, accessName, subTypes, displayName);
		return users;
	}

//	private List<User> getUsersOfUnitByTypes(String unitId,
//			List<UserTypeModel> userTypeModels, Boolean status) {
//		return userDao.getUsersOfUnitByTypes(unitId, userTypeModels, status);
//	}

	public List<User> getUserNameById(List<String> listofHistoryById) {
		return userDao.getUserNameById(listofHistoryById);
	}

//	public Boolean checkUnitIdAssigned(String unitId) {
//		return userDao.checkUnitIdAssigned(unitId);
//	}

//	public List<User> getUsersBySubType(List<String> subTypes) {
//		return userDao.getUsersBySubType(subTypes);
//	}

//	public boolean checkMappingExist(String userId, String employeeId) {
//		return userDao.checkMappingExist(userId, employeeId);
//	}

//	public User findByEmployeeId(String employeeId) {
//		return userDao.findByEmployeeId(employeeId);
//	}

//	public User findById(String userId) {
//		return userDao.findById(userId);
//	}

//	public User getUserByUserId(String userId) {
//		return userDao.getUserByUserId(userId);
//	}

//	public Map<String, String> getUserMap() {
//		Map<String, String> userMap = new HashMap<>();
//		List<User> users = userDao.getUsers();
//		for (User user : users) {
//			userMap.put(user.getId(), user.getDisplayName());
//		}
//		return userMap;
//	}

	public List<User> getActiveUserByRole(List<String> roleAccessList) {
		return userDao.getActiveUserByRole(roleAccessList);
	}

	public List<User> getActiveUsersByAnyRole(List<String> roleAccessList) {
		return userDao.getActiveUsersByAnyRole(roleAccessList);
	}

	public User findOneSmallUserById(String id) {
		return userDao.findOneSmallUserById(id);
	}

	public List<String> getUserId(String userId) {
		return MongoUtils.getStringFromObjectIds(userDao.getUserIdForLogView(userId));
	}

}
