package com.project.retail.system.model;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

import com.project.retail.system.constants.AppType;

@Document(collection = "clientAppVersion")
public class ClientAppVersion extends AbstractDocument {

	private String version;
	private String url;
	private String urlDicom;
	private boolean downloadVersion;
	private AppType appType;
	private Date versionDate;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrlDicom() {
		return urlDicom;
	}

	public void setUrlDicom(String urlDicom) {
		this.urlDicom = urlDicom;
	}

	public boolean isDownloadVersion() {
		return downloadVersion;
	}

	public void setDownloadVersion(boolean downloadVersion) {
		this.downloadVersion = downloadVersion;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public AppType getAppType() {
		return appType;
	}

	public void setAppType(AppType appType) {
		this.appType = appType;
	}

	@Override
	public String toString() {
		return "ClientAppVersion [version=" + version + ", url=" + url
				+ ", urlDicom=" + urlDicom + ", downloadVersion="
				+ downloadVersion + ", appType=" + appType + ", versionDate="
				+ versionDate + "]";
	}

}
