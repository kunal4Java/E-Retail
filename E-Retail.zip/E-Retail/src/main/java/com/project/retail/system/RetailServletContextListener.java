package com.project.retail.system;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class RetailServletContextListener implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		

	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {

	}
}
