package com.project.retail.system.model;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.project.retail.system.annotation.SetToNull;

@Document(collection = "userTypeMaster")
public class UserTypeMaster extends AbstractDocument {

	private String type;
	private List<UserSubType> userSubTypes;
	private Boolean status;
	private Boolean defaultStatus;
	@SetToNull
	private String expenseItemGroupId;

	public String getType() {
		return type;
	}

	public Boolean getStatus() {
		return status;
	}

	public Boolean getDefaultStatus() {
		return defaultStatus;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public void setDefaultStatus(Boolean defaultStatus) {
		this.defaultStatus = defaultStatus;
	}

	public List<UserSubType> getUserSubTypes() {
		return userSubTypes;
	}

	public void setUserSubTypes(List<UserSubType> userSubTypes) {
		this.userSubTypes = userSubTypes;
	}

	public String getExpenseItemGroupId() {
		return expenseItemGroupId;
	}

	public void setExpenseItemGroupId(String expenseItemGroupId) {
		this.expenseItemGroupId = expenseItemGroupId;
	}

	@Override
	public String toString() {
		return "UserTypeMaster [type=" + type + ", userSubTypes="
				+ userSubTypes + ", status=" + status + ", defaultStatus="
				+ defaultStatus + ", expenseItemGroupId=" + expenseItemGroupId
				+ "]";
	}

}
