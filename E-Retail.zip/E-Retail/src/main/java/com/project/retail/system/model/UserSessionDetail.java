package com.project.retail.system.model;

import java.util.Date;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.project.retail.system.annotation.NoHistory;
import com.project.retail.system.constants.AppType;
import com.project.retail.system.constants.SessionType;

@Document(collection = "userSessionDetail")
@NoHistory
public class UserSessionDetail extends AbstractDocument {

	private String userId;
	@Indexed(useGeneratedName = true, background = true)
	private String userMongoId;
	@Indexed(useGeneratedName = true, background = true)
	private Date time;
	private SessionType sessionType;
	private String ipAddress;
	@Indexed(useGeneratedName = true, background = true)
	@JsonIgnore
	private String token_id;
	private String hostPcName;
	private String macAddress;
	private AppType appType;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserMongoId() {
		return userMongoId;
	}
	public void setUserMongoId(String userMongoId) {
		this.userMongoId = userMongoId;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public SessionType getSessionType() {
		return sessionType;
	}
	public void setSessionType(SessionType sessionType) {
		this.sessionType = sessionType;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getToken_id() {
		return token_id;
	}
	public void setToken_id(String token_id) {
		this.token_id = token_id;
	}
	public String getHostPcName() {
		return hostPcName;
	}
	public void setHostPcName(String hostPcName) {
		this.hostPcName = hostPcName;
	}
	public String getMacAddress() {
		return macAddress;
	}
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public AppType getAppType() {
		return appType;
	}
	public void setAppType(AppType appType) {
		this.appType = appType;
	}
	
	@Override
	public String toString() {
		return "UserSessionDetail [userId=" + userId + ", userMongoId="
				+ userMongoId + ", time=" + time + ", sessionType="
				+ sessionType + ", ipAddress=" + ipAddress + ", token_id="
				+ token_id + ", hostPcName=" + hostPcName + ", macAddress="
				+ macAddress + ", appType=" + appType + "]";
	}
	
}
