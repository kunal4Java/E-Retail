package com.project.retail.system.service;

import java.io.Serializable;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.project.retail.system.dao.RetailDao;
import com.project.retail.system.model.AbstractDocument;
import com.project.retail.system.oauth2.ClientDetailsService;
import com.project.retail.system.oauth2.UserDetail;

public class RetailService<T extends AbstractDocument, ID extends Serializable>{

	@Autowired
	ClientDetailsService tempInMemoryClientDetailsService;
	
	RetailDao<T, Serializable> hmisDao;
	
	private Logger logger = Logger.getLogger(getClass());
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public RetailService(RetailDao dao) {
		this.hmisDao = dao;
	}
	
	public long count() {
		return hmisDao.count();
	}
	
	public T findOne(ID id) {
		return hmisDao.findOne(id);
	}
	
	public T findOneWithoutHistory(ID id) {
		return hmisDao.findOneWithoutHistory(id);
	}

	public List<T> findAll() {
		return hmisDao.findAll();
	}
	
	public List<T> findAllWithoutHistory() {
		return hmisDao.findAllWithoutHistory();
	}

	public List<T> findAll(T T) {
		return hmisDao.findAll(T);
	}

	public String getLoggedUserMongoId(){
		UserDetail userDetail = tempInMemoryClientDetailsService.getUserDetail();
		return userDetail != null? userDetail.getUserMongoId() : null;
	}
	
	public String getLoggedDisplayUserName(){
		UserDetail userDetail = tempInMemoryClientDetailsService.getUserDetail();
		return userDetail != null? userDetail.getDisplayUserName() : null;
	}

	public T save(T T , String action) {
		return hmisDao.save(T , action);
	}
	
	@Deprecated
	public T save(T T) {
		return hmisDao.save(T);
	}
	
	public Object save(List<T> T , String action) {
		return hmisDao.save(T , action);
	}
	
	@Deprecated
	public Object save(List<T> T) {
		return hmisDao.save(T);
	}
	
	public void delete(T T) {
		hmisDao.delete(T);
	}

	public void delete(ID id) {
		hmisDao.delete(id);
	}
	
	public void deleteAll() {
		hmisDao.deleteAll();
	}

	public void update(T entity, String action) {
		hmisDao.update(entity , action);
	}
	
	@Deprecated
	public void update(T entity) {
		hmisDao.update(entity);
	}
	
	public void upsert(T entity , String action) {
		hmisDao.upsert(entity , action);
	}
	
	public void upsertWithNull(T entity , String action) {
		hmisDao.upsertWithNull(entity , action);
	}
	
	@Deprecated
	public void upsert(T entity) {
		hmisDao.upsert(entity);
	}
	
	public void updateWithNull(T entity , String action) {
		hmisDao.updateWithNull(entity, action);
	}
	
	@Deprecated
	public void updateWithNull(T entity) {
		hmisDao.updateWithNull(entity);
	}
	
	public boolean uniqueCheck(String key , String value , String id) {
		return hmisDao.uniqueCheck(key, value, id);
	}
	
	public List<T> findAll_B(){
		return hmisDao.findAll_B();
	}
	
	public List<T> findAll_E(){
		return hmisDao.findAll_E();
	}	
}
