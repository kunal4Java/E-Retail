package com.project.retail.system.dao;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.project.retail.system.model.UserTypeMaster;

@Repository
public class UserTypeMasterDao extends RetailDao<UserTypeMaster, String> {

	public Boolean checkDuplicateType(UserTypeMaster userTypeMaster) {
		Query query = new Query();
		query.addCriteria(Criteria.where("type").regex("^" + userTypeMaster.getType() + "$", "i"));
		if(userTypeMaster.getId() != null) {
			query.addCriteria(Criteria.where("id").ne(userTypeMaster.getId())); // in case of update
		}
		
		return (findOne(query) != null);
	}

	public List<UserTypeMaster> list() {
		Query query = new Query();
		query.with(new Sort(Direction.ASC, "type"));	
		return findAll();
	}

}
