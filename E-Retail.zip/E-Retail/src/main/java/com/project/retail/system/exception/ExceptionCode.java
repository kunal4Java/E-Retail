package com.project.retail.system.exception;

public enum ExceptionCode {

	 NOT_FOUND(404),CONFLICT(409),BAD_REQUEST(400),METHOD_NOT_ALLOWED(405),NOT_ACCEPTABLE(406),UNSUPPORTED_MEDIA_TYPE(415),INTERNAL_SERVER_ERROR(500) ;
	
	private int code;
	    
	    private ExceptionCode(int code){
	        this.code = code;
	    }
	    
	    public int getCode(){
	        return this.code;
	    }
}
