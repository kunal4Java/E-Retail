package com.project.retail.system.constants;

public enum LoginType {

	USER , PATIENT
}
