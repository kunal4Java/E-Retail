package com.project.retail.system.oauth2;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

public class BasePermissionEvaluator implements PermissionEvaluator {

	Logger logger = Logger.getLogger(BasePermissionEvaluator.class);
	
	@Override
	public boolean hasPermission(Authentication authentication,
			Object targetDomainObject, Object permission) {
		
		logger.info("--- >> hasPermission \n--- >> authentication :: " + authentication.getAuthorities() + "\n --->>> permission ::" + permission );
		
		GrantedAuthority authorityImpl =  new SimpleGrantedAuthority(permission.toString());
		
		return authentication.getAuthorities().contains(authorityImpl);
	}

	@Override
	public boolean hasPermission(Authentication authentication,
			Serializable targetId, String targetType, Object permission) {

		logger.info("hasPermission(Authentication authentication,Serializable targetId, String targetType, Object permission)");
		
		return false;
	}

}
