package com.project.retail.system.util;

import static java.lang.Math.floor;
import static java.lang.Math.log;

public class AlphabeticNameGeneration {

	private static char[] vs;
	
    static {
    	vs = new char['Z' - 'A' + 1];
    	for (char i = 'A'; i <= 'Z'; i++)
    		vs[i - 'A'] = i;
    }

    private static StringBuilder alpha(int i) {
    	assert i > 0;
    	char r = vs[--i % vs.length];
    	int n = i / vs.length;
    	return n == 0 ? new StringBuilder().append(r) : alpha(n).append(r);
    }

    protected static String computeNext(int now) {
    	return alpha(++now).toString();
    }
    
    public static String getNameFromIndex(int n) {
	    char[] buf = new char[(int) floor(log(25 * (n + 1)) / log(26))];
	    for (int i = buf.length - 1; i >= 0; i--) {
	        n--;
	        buf[i] = (char) ('A' + n % 26);
	        n /= 26;
	    }
	    return new String(buf);
    }
}
