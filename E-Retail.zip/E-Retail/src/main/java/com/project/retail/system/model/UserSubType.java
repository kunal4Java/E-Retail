package com.project.retail.system.model;

public class UserSubType {

	private String subType;
	private Boolean defaultStatus;
	private String expenseItemGroupId;

	public String getSubType() {
		return subType;
	}

	public Boolean getDefaultStatus() {
		return defaultStatus;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public void setDefaultStatus(Boolean defaultStatus) {
		this.defaultStatus = defaultStatus;
	}
	
	public String getExpenseItemGroupId() {
		return expenseItemGroupId;
	}

	public void setExpenseItemGroupId(String expenseItemGroupId) {
		this.expenseItemGroupId = expenseItemGroupId;
	}

	@Override
	public String toString() {
		return "UserSubType [subType=" + subType + ", defaultStatus="
				+ defaultStatus + ", expenseItemGroupId=" + expenseItemGroupId
				+ "]";
	}

}
