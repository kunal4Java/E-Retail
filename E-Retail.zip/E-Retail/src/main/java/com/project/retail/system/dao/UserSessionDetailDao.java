package com.project.retail.system.dao;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.project.retail.system.constants.GetOnScrollType;
import com.project.retail.system.constants.SessionType;
import com.project.retail.system.model.UserSessionDetail;

@Repository
public class UserSessionDetailDao extends RetailDao<UserSessionDetail, String>{

	private Logger logger = Logger.getLogger(getClass());
	
	public UserSessionDetail getLoginSessionByUserAndTokenId(String token_id,
			String userMongoId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("userMongoId").is(userMongoId));
		query.addCriteria(Criteria.where("token_id").is(token_id));
		query.addCriteria(Criteria.where("sessionType").is(SessionType.LOGIN.name()));
		query.fields().include("appType");
		return findOne(query);
	}

	public List<UserSessionDetail> search(String userId, Date from, Date to,
			Integer skip, Integer pageSize, String lastId, GetOnScrollType getOnScrollType) {
		
		Criteria criteria = new Criteria();
		
		if(userId != null){
			criteria.and("userId").is(userId);
		}
		
		if (to != null && from != null) {
			criteria.and("time").gte(from).lte(to);
		} else if (to == null && from != null) {
			criteria.and("time").gte(from);
		} else if (to != null && from == null) {
			criteria.and("time").lte(to);
		} 
		
		Query query = new Query();
		query.addCriteria(criteria);
		
		if(pageSize != null){
			query.limit(pageSize);
		}
		
		if(getOnScrollType != null) {
			switch (getOnScrollType) {
			case Id_Wise:
				if(lastId != null){
					//NEVER USE SORTING WITH THIS CONDITION
					query.addCriteria(Criteria.where("_id").lt(new ObjectId(lastId)));
				}
				break;
			case Skip_Wise:
				query.skip(skip);
				break;
			default:
				break;
			}
		}
		query.with(new Sort(Direction.DESC, "_id"));
		return find(query);
	}
}
