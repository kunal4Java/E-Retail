/*
 * To change this template, choose Tools | Templates and open the template in the editor.
 */
package com.project.retail.system.util;

import java.util.Calendar;
import java.util.Date;

/**
 * 
 * Common String and Date related utils.
 * 
 */
public class MyUtils {

	public static final String DISPLAY_NONE = "display:none;";

	public static String getDefaultValue(String value) {
		if (value == null || value.equals("")) {
			return "-";
		}
		return value;
	}

	public static String getDefaultValue(Double dvalue) {
		if (dvalue == null) {
			return "-";
		}
		return dvalue.toString();
	}

	public static String getDefaultValue(Integer value) {
		if (value == null) {
			return "-";
		}
		return value.toString();
	}

	public static String getStringValue(String value) {
		if (value == null) {
			return "";
		}
		return value;
	}

	public static String getStringValue(Double dvalue) {
		if (dvalue == null) {
			return "";
		}
		return dvalue.toString();
	}

	public static String getStringValue(Long lvalue) {
		if (lvalue == null) {
			return "";
		}
		return lvalue.toString();
	}

	public static String getStringValue(Integer value) {
		if (value == null) {
			return "";
		}
		return value.toString();
	}

	public static String getStringValueForIntake(Double dvalue) {
		if (dvalue == 0.0) {
			return "-";
		}
		return dvalue.toString();
	}

	public static Double getDoubleFromString(String field) {
		if (field != null && !field.isEmpty()) {
			return Double.parseDouble(field);
		}
		return 0.0;
	}

	public static Double getDoubleFromValue(Double value) {
		if (value == null) {
			return 0.0;
		}
		return value;
	}

	public static Integer getIntegerFromString(String field) {
		if (field != null && !field.isEmpty()) {
			return Integer.parseInt(field);
		}
		return 0;
	}
	
	public static Integer getIntegerFromValue(Integer value) {
		if (value == null) {
			return 0;
		}
		return value;
	}

	/**
	 * functions to have same return string to all the project strings.
	 */
	public static String DEFAULT_EMPTY_STRING = "";

	public static String getString(String val) {
		if (val == null) {
			return DEFAULT_EMPTY_STRING;
		}
		return val.trim().toString();
	}

	public static String getString(Integer val) {
		if (val == null) {
			return DEFAULT_EMPTY_STRING;
		}
		return val.toString();
	}

	public static String getString(Double val) {
		if (val == null) {
			return DEFAULT_EMPTY_STRING;
		}
		return val.toString();
	}

	public static String getString(Float val) {
		if (val == null) {
			return DEFAULT_EMPTY_STRING;
		}
		return val.toString();
	}

	public static String getString(Boolean val) {
		if (val == null) {
			return "No";
		} else if (val) {
			return "Yes";
		} else {
			return "No";
		}
	}

	public static boolean getBooleanFromValue(Boolean value) {
		if (value == null) {
			return false;
		}
		return value;
	}

	public static String getValueFromBoolean(Boolean value) {
		if (value == null) {
			return "";
		} else {
			return value ? "Yes" : "No";
		}

	}

	/**
	 * Compare to Arrays of Integer. Used to perform bitwise or operator between
	 * two integer Array
	 * 
	 * @param first
	 *            the firstArray
	 * @param second
	 *            the secondArray
	 * @return the integer[]
	 */
	public static Integer[] compare(Integer[] first, Integer[] second)
			throws ArrayIndexOutOfBoundsException {
		Integer[] result = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0 };
		for (int i = 0; i < result.length; i++) {
			result[i] = first[i].intValue() | second[i].intValue();
		}
		return result;
	}

	public static String generateRandomString(int length) {

		StringBuffer buffer = new StringBuffer();
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789@#";

		int charactersLength = characters.length();

		for (int i = 0; i < length; i++) {
			double index = Math.random() * charactersLength;
			buffer.append(characters.charAt((int) index));
		}
		return buffer.toString();
	}

	public static String checkFirstValue(String string) {
		string = string.startsWith(",") ? string.substring(1) : string;
		string = string.startsWith(" ,") ? string.substring(2) : string;
		string = string.startsWith("  ,") ? string.substring(3) : string;
		return string;
	}

	public static String checkLastValue(String string) {
		string = string.endsWith(",") ? string
				.substring(0, string.length() - 1) : string;
		string = string.endsWith(", ") ? string.substring(0,
				string.length() - 2) : string;
		return string;
	}
	
	/**
	 * Get Age in months and years from Date of birth
	 * 
	 * @param date
	 *            date
	 * @return age in months
	 */
	public static String getAgeInDayMonthsAndYearsFromDOB(Date date) {
		Calendar dob = Calendar.getInstance();
		dob.setTime(date);
		Calendar today = Calendar.getInstance();

		// logger.info("today :: " + today.getTime());

		int years = 0;
		int months = 0;
		int days = 0;
		if (today.after(dob)) {
			years = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

			if (today.get(Calendar.MONTH) < dob.get(Calendar.MONTH)) {
				years--;
				months = today.getMaximum(Calendar.MONTH)
						+ today.get(Calendar.MONTH) - dob.get(Calendar.MONTH);
			} else {
				months = today.get(Calendar.MONTH) - dob.get(Calendar.MONTH);
			}
			if (today.get(Calendar.DAY_OF_MONTH) < dob
					.get(Calendar.DAY_OF_MONTH)) {
				months--;
				today.set(Calendar.MONTH, today.get(Calendar.MONTH) - 1);
				days = today.getActualMaximum(Calendar.DAY_OF_MONTH);
				days += today.get(Calendar.DAY_OF_MONTH)
						- dob.get(Calendar.DAY_OF_MONTH);
			} else {
				days = today.get(Calendar.DAY_OF_MONTH)
						- dob.get(Calendar.DAY_OF_MONTH);
			}

		} else {
			return "Invalid";
		}
		if (years == 0) {
			return months + "m " + days + "d";
		} else {
			return years + "y " + months + "m";
		}

	}

	/* Used for css purpose */
	public static String getStringCss(Date date) {
		if (date == null) {
			return DISPLAY_NONE;
		}
		return "";
	}

	public static String getStringCss(String string) {
		if (string == null) {
			return DISPLAY_NONE;
		} else if (string.equals("")) {
			return DISPLAY_NONE;
		}
		return "";
	}

	public static String getStringCss(Boolean value) {
		if (value == null) {
			return DISPLAY_NONE;
		}
		return "";
	}

	public static String getStringCss(Integer value) {
		if (value == null) {
			return DISPLAY_NONE;
		}
		return "";
	}

	public static String getStringCss(Double value) {
		if (value == null) {
			return DISPLAY_NONE;
		}
		return "";
	}

	public static String getStringCssForCheckBox(Boolean value) {
		if (value == null) {
			return DISPLAY_NONE;
		}
		String valueString = MyUtils.getValueFromBoolean(value);
		return valueString.equals("Yes") ? "" : DISPLAY_NONE;
	}

	/**
	 * Used for hide blog in print if every field has no data nd display none
	 * accordingly
	 * 
	 * @param string
	 *            the string
	 * @param value
	 *            the flag
	 * @return the boolean
	 */
	public static Boolean checkBoolean(String string, Boolean value) {
		return string == null || string.equals("") ? value : false;
	}

	public static Boolean checkBoolean(Integer integer, Boolean value) {
		return integer == null ? value : false;
	}

	public static Boolean checkBoolean(Double double1, Boolean value) {
		return double1 == null ? value : false;
	}

	/**
	 * Used for hide blog in print if every field has no data nd display none
	 * accordingly
	 * 
	 * @param Boolean
	 *            the boolean Value
	 * @param value
	 *            the flag
	 * @return the boolean
	 */
	public static Boolean checkBoolean(Boolean booleanstring, Boolean value) {
		return booleanstring == null ? value : false;
	}

	public static boolean isDefaultEditorContent(String htmlString) {
		return htmlString
				.equalsIgnoreCase("<html dir=\"ltr\"><head></head><body contenteditable=\"true\"></body></html>");
	}
}
