package com.project.retail.system.util;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.util.Assert;

public class DateUtils {

	public static final String DATE_FORMAT = "dd-MMM-yyyy";
	public static final String DATE_TIME_FORMAT1 = "dd-MMM-yyyy_HH-mm-ss";
	public static final String DATE_TIME_FORMAT2 = "dd-MMM-yyyy HH:mm:ss";
	public static final String DATE_TIME_FORMAT = "dd-MMM-yyyy HH:mm";
	public static final String TIME_FORMAT = "HH:mm";
	public static final String DAY_TIME_FORMAT = "E, dd MMM yyyy hh:mm a";
//	public static SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(DATE_FORMAT);
//	public static SimpleDateFormat SIMPLE_DATE_TIME_FORMAT = new SimpleDateFormat(DATE_TIME_FORMAT);
//	public static SimpleDateFormat SIMPLE_DAY_TIME_FORMAT = new SimpleDateFormat(DAY_TIME_FORMAT);
//	public static SimpleDateFormat SIMPLE_TIME_FORMAT = new SimpleDateFormat(TIME_FORMAT);
	
	/**
	 * Format date by removing extra space.
	 * use only for making folder according to date.
	 *
	 * @param dateFormat the date format
	 * @return the string
	 */
	public static String formatDate(String dateFormat) {
		dateFormat  = dateFormat.replaceAll("\\s+", "_").trim();
		return dateFormat;
	}
	
	public static String getDateFormat(Date date) {
		return getDateFormat(date ,DATE_TIME_FORMAT1);
	}
	
	public static String getDateFormatNormal(Date date) {
		return getDateFormat(date ,DATE_TIME_FORMAT2);
	}
	
	/**
	 * Get date string in default format.
	 * 
	 * @param date
	 * @param dateFormat
	 * 
	 * @return Date String with Give format
	 */
	public static String getDateFormat(Date date , String dateFormat) {
		if (date == null) {
			return "";
		}
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
		return simpleDateFormat.format(date);
	}
	
	public static Integer getHours(Integer minutes) {
		Integer hours = minutes/60;
		
		return hours;
	}
	
	public static Integer getMinutes(Integer minutes) {
		Integer minute = minutes%60;
		return minute;
	}
	
	public static Date setDateTo1Jan(Date date){
		
		Assert.notNull(date, "Date Must Not be Null");
		
		Calendar calendar = Calendar.getInstance();
		
		calendar.setTime(date);

		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		calendar.set(Calendar.MONTH, 0);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		
		return calendar.getTime();
		
	}
	
	
	public static Date setDateTo31Dec(Date date){
		
		Assert.notNull(date, "Date Must Not be Null");
		
		Calendar calendar = Calendar.getInstance();
		
		calendar.setTime(date);

		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 0);
		calendar.set(Calendar.MONTH, 11);
		calendar.set(Calendar.DAY_OF_MONTH, 31);
		
		return calendar.getTime();
		
	}
	
	public static Date setFromTimeTo0Hour(Date date){
		
		Assert.notNull(date, "Date Must Not be Null");
		
		Calendar calendar = Calendar.getInstance();
		
		calendar.setTime(date);

		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		
		return calendar.getTime();
		
	}
	
	public static Date setToTimeTo24Hour(Date date){
		
		Assert.notNull(date, "Date Must Not be Null");
		
		Calendar calendar = Calendar.getInstance();
		
		calendar.setTime(date);

		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 0);
		
		return calendar.getTime();
		
	}
	
	public static String getDefaultDateTimeWithDay(Date date) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat SIMPLE_DAY_TIME_FORMAT = new SimpleDateFormat(DAY_TIME_FORMAT);
		return SIMPLE_DAY_TIME_FORMAT.format(date);
	}
	public static String getDefaultDate(Date date) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(DATE_FORMAT);
		return SIMPLE_DATE_FORMAT.format(date);
	}
	
	/**
     * Get age in years from Date of Birth
     *
     * @param date
     *            date
     * @return age in years
     */
    public static int getAgeFromDOB(Date date) {
        Calendar dob = Calendar.getInstance();
        dob.setTime(date);
        Calendar today = Calendar.getInstance();
        return today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
    }
    
    public static Long getMinutesFromDate(Date date){
    	Calendar calendar = Calendar.getInstance();
    	calendar.setTime(date);
    	Integer minutes = calendar.get(Calendar.HOUR_OF_DAY) * 60;
    	minutes += calendar.get(Calendar.MINUTE);
    	return Long.parseLong(minutes.toString());
    }
    
    public static Date getTimeWithMinuteSpecified(Date date, int hour,int minutes) {
    	Calendar calendar = Calendar.getInstance();
    	calendar.setTime(date);
    	calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minutes);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
    }
    
    public static int getHourFromDate(Date date) {
    	Calendar calendar = Calendar.getInstance();
    	calendar.setTime(date);
    	Integer hour = calendar.get(Calendar.HOUR_OF_DAY);
    	return hour;
    }
    
    public static int getMinFromDate(Date date) {
    	Calendar calendar = Calendar.getInstance();
    	calendar.setTime(date);
    	Integer hour = calendar.get(Calendar.MINUTE);
    	return hour;
    }
    
    public static int getMinBetweenTwoDate(Date from , Date to){
    	long diff = to.getTime() - from.getTime();
        int diffMinutes = (int)diff / (60 * 1000);
        return diffMinutes;
    }
    
    public static long getMinBetweenTwoDateInLong(Date from , Date to){
    	long diff = to.getTime() - from.getTime();
        long diffMinutes = diff / (60 * 1000);
        return diffMinutes;
    }

    /**
	 * Get date with time string in default format.
	 * 
	 * @param date
	 *            Date
	 * @return Date and time in default format
	 */
	public static String getDefaultDateTime(Date date) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat SIMPLE_DATE_TIME_FORMAT = new SimpleDateFormat(DATE_TIME_FORMAT);
		return SIMPLE_DATE_TIME_FORMAT.format(date);
	}
	
	/**
	 * @param from
	 * @param to
	 * @return List of date between two dates 
	 */
	public static List<Date> getListFromDates(Date from, Date to) {
		List<Date> dates = new ArrayList<Date>();
		Calendar cal = Calendar.getInstance();
		cal.setTime(from);
		dates.add(from);
		while (cal.getTime().before(to)) {
		    cal.add(Calendar.DATE, 1);
		    dates.add(cal.getTime());
		}
		return dates;
	}

	/**
	 * Get Age in months from Date of birth
	 * 
	 * @param date
	 *            date
	 * @return age in months
	 */
	public static int getAgeInMonthsFromDOB(Date date) {
		Calendar dob = Calendar.getInstance();
		dob.setTime(date);
		Calendar today = Calendar.getInstance();
		return today.get(Calendar.YEAR) * 12 + today.get(Calendar.MONTH) - (dob.get(Calendar.YEAR) * 12 + dob.get(Calendar.MONTH));
	}
	
	public static Date incrementDate(Date date) {
		Calendar calendarShift = Calendar.getInstance();
		calendarShift.setTime(date);
		calendarShift.add(Calendar.DATE, 1);
		return calendarShift.getTime();
	}
	
	public static Date decrementDate(Date date) {
		Calendar calendarShift = Calendar.getInstance();
		calendarShift.setTime(date);
		calendarShift.add(Calendar.DATE, -1);
		return calendarShift.getTime();
	}
	
	/**
     * Get Age in months and years from Date of birth
     *
     * @param date
     *            date
     * @return age in months
     */
	public static String getAgeInDayMonthsAndYearsFromDOB(Date birthDate) {
	       
        LocalDate today = LocalDate.now();
        LocalDate birthday = birthDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
         
        Period period = Period.between(birthday, today);
         
        // Create new Age object
        if (period.getYears() == 0) {
            return period.getMonths() + "m " + period.getDays() + "d";
        } else {
            return period.getYears() + "y " + period.getMonths() + "m";
        }
    }
    
    /**
	 * check whether dates conflict with existing date
	 * 
	 * @param schemeStartDt
	 * 			start date of existing scheme
	 * @param schemeEndDt
	 * 			end date of existing scheme
	 * @param startDate
	 * 			start date of new scheme
	 * @param endDate
	 * 			end date of new scheme
	 * @return 
	 * 			true if conflicts occurs
	 * 			false if no conflict between dates
	 */
	public static boolean isDateConflictsForScheme(Date schemeStartDt, Date schemeEndDt,
			Date startDate, Date endDate) { 
		if (schemeStartDt == null && schemeEndDt == null) {
			return true;
		}
//		schemeEndDt.equals(endDate) ||schemeEndDt.before(endDate)
//		schemeStartDt.after(startDate) || schemeStartDt.equals(startDate))
		// if both date is exists
		if (startDate != null && endDate != null) {
			// if both date of applied schemes exists
			if (schemeStartDt != null && schemeEndDt != null) {
				if ((schemeStartDt.before(endDate) && !schemeStartDt.before(startDate))
						|| (!schemeEndDt.after(endDate) 
								&& schemeEndDt.after(startDate))
						|| (!schemeStartDt.before(startDate) 
								&& !schemeEndDt.after(endDate))
						|| (schemeStartDt).before(startDate) && schemeEndDt
								.after(endDate)) {
					return true;
				}
			} else if (schemeStartDt != null) { // if start date
												// of applied
												// schemes
												// exists
				if (schemeStartDt.before(endDate)) {
					return true;
				}
			} else if (schemeEndDt != null) { // if end date of
												// applied
												// schemes
												// exists
				if (schemeEndDt.after(startDate)) {
					return true;
				}
			}

		} else if (endDate != null) {// if end date exists
			if (schemeStartDt != null) {
				if (schemeStartDt.before(endDate)) {
					return true;
				}
			} else if (schemeEndDt != null) {
				// ask to give option to set date here
				return true;
			}
		} else if (startDate != null) {// if start date exists
			if (schemeEndDt != null) {
				if (schemeEndDt.after(startDate)) {
					return true;
				}
			} else if (schemeStartDt != null) {
				// ask to give option to set date here
				return true;
			}
		} else {
			if(schemeStartDt != null || schemeEndDt != null){
				return true;
			}
		}
		
		return false;
	}
	
	public static Date getDOBFromAge(int age) {
		Calendar today = Calendar.getInstance();
		today.add(Calendar.YEAR, -1 * age);
		return today.getTime();
	}

	public static Date getDateFromMonthAndYear(int day, int months, int year, int hour, int min) {
		Calendar calendar = Calendar.getInstance();
    	calendar.set(Calendar.DAY_OF_MONTH, day);
		calendar.set(Calendar.MONDAY, months);
		calendar.set(Calendar.YEAR, year);
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, min);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	public static Date decrementDateByDays(Date date, int days){
		
		Assert.notNull(date, "Date Must Not be Null");
		
		Calendar calendar = Calendar.getInstance();
		
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		
		calendar.add(Calendar.DATE, -days);
		return calendar.getTime();

	}
	
	public static Date incrementDateByDays(Date date, int days){
		
		Assert.notNull(date, "Date Must Not be Null");
		
		Calendar calendar = Calendar.getInstance();
		
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		
		calendar.add(Calendar.DATE, days);
		return calendar.getTime();

	}
	
	public static int getDayOfYearFromDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(Calendar.DAY_OF_YEAR);
	}

}
