package com.project.retail.system.util;

import java.util.Date;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.core.io.support.PropertiesLoaderUtils;

public class CustomMailUtils {
	public static void sendMail(String emailSubject, String emailBody) throws Exception {
		
		Properties emailConfiguration = PropertiesLoaderUtils.loadAllProperties("local.properties");
		String hostName = emailConfiguration.getProperty("hostName");
		String portName = emailConfiguration.getProperty("portName");
		String accountDisplayName = emailConfiguration.getProperty("accountDisplayName");
		String receiverEmailID = emailConfiguration.getProperty("receiverEmailId");
		final String emailId = emailConfiguration.getProperty("emailAddress");
		final String passwords = emailConfiguration.getProperty("password");
		
		Properties properties = new Properties();
		properties.put("mail.transport.protocol", "smtp");
		properties.put("mail.smtp.host", hostName);
		properties.put("mail.smtp.port",portName);
		properties.put("mail.debug", "true");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.ssl.enable", "true");
		properties.put("mail.smtp.text", "text/plain");

		Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(emailId, passwords);
			}
		});
		
		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress(emailId, accountDisplayName));
		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(receiverEmailID));
		message.setSubject(emailSubject);
		message.setSentDate(new Date());

		BodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setHeader("Content-Type", "text/html");
		messageBodyPart.setContent(emailBody, "text/html; charset=ISO-8859-1");

		Multipart multipart = new MimeMultipart("related");
		
		multipart.addBodyPart(messageBodyPart);
		
		/*if (attachmentFilepath != null && attachmentFilepath.size() > 0) {
			int i = 0;
			while (i < attachmentFilepath.size()) {
				BodyPart attachment = new MimeBodyPart();
				DataSource source = new FileDataSource(new File(attachmentFilepath.get(i)));
				attachment.setDataHandler(new DataHandler(source));
				attachment.setFileName(source.getName());
				multipart.addBodyPart(attachment);
				i++;
			}
		}
		*/
		message.setContent(multipart);
		Transport.send(message);// This statement send Message.
	}
	
	public static void sendMailWithoutAttachment(String emailSubject, String emailBody) throws Exception {
		sendMail(emailSubject, emailBody);
	}
	
	/*public static void sendMailWithAttachment(EmailConfigurationMaster emailConfigurationMaster, String receiverEmailID,
		String emailSubject, String emailBody, ArrayList<String> attachmentFilepath) throws Exception {
		sendMail(emailConfigurationMaster, receiverEmailID, emailSubject, emailBody, attachmentFilepath);
	}*/

	
}

