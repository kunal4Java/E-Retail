package com.project.retail.system.constants;

public enum SessionType {

	LOGIN("Login"),
	VULNERABLE_LOGIN("Vulnerable Login"),
	LOGOUT("Logout");
	
	private String sessionType;
	
	private SessionType(String sessionType){
		this.sessionType = sessionType;
	}
	
	public String getSessionType() {
		return sessionType;
	}

	@Override
	public String toString() {
		return sessionType;
	}
}
