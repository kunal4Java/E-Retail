package com.project.retail.system.oauth2;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.DefaultAuthorizationRequest;
import org.springframework.security.oauth2.provider.token.InMemoryTokenStore;
import org.springframework.stereotype.Component;

@Component
public class SessionListener implements HttpSessionListener  {

	private static final Logger logger = Logger.getLogger(SessionListener.class);
	
	@Autowired
	UserApprovalHandler userApprovalHandler;
	
	@Autowired
	ClientDetailsService clientDetailsService;

	@Autowired
	InMemoryTokenStore tokenStore;
	
	
	@Override
	public void sessionCreated(HttpSessionEvent se) {
		
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		
		HttpSession session = se.getSession();
		
		String token_id = (String) session.getAttribute("token_id");
		
		logger.info("sessionDestroyed -- > " +  token_id);
		
        DefaultAuthorizationRequest defaultAuthorizationRequest = new DefaultAuthorizationRequest(token_id, new ArrayList<String>());
          
		if (userApprovalHandler.isApproved(defaultAuthorizationRequest, null)) {
			
			OAuth2AccessToken accessToken = userApprovalHandler.getAccessToken(defaultAuthorizationRequest, null);

			if (accessToken != null) {
				tokenStore.removeAccessToken(accessToken);
				clientDetailsService.remove(token_id);
				
				logger.info("Remove token_id-- > " +  token_id);
			}
		}
	}
}
