package com.project.retail.system.model.Response;

import java.util.List;

import com.project.retail.system.constants.UserType.*;

public class UserTypeModel {

	private Type userType;
	private List<SubType> subTypes;
	
	public Type getUserType() {
		return userType;
	}

	public void setUserType(Type userType) {
		this.userType = userType;
	}

	public List<SubType> getSubTypes() {
		return subTypes;
	}

	public void setSubTypes(List<SubType> subTypes) {
		this.subTypes = subTypes;
	}

	@Override
	public String toString() {
		return "UserTypeModel [userType=" + userType + ", subTypes=" + subTypes
				+ "]";
	}
	
}
