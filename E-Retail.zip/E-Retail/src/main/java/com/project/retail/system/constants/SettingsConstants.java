package com.project.retail.system.constants;

import java.io.File;

public class SettingsConstants {

	public static String saveFolderLocation;

	public static String mongoDbBackupLocation;

	public static String mongoDbExceptionLocation;

	public static String fileBackupLocation;

	public static String eRetailDataPath;
	public static String DOCUMENT_ROOT_PATH;
	public static String USER_PHOTO_PATH;
	public static String TEMP_FILES_PATH;
	
	public static String defaultUserPhotoPath;

	public static void setDataPath(String dataPath) {

		saveFolderLocation = dataPath;

		mongoDbBackupLocation = saveFolderLocation + File.separator + "MongoBackUp";

		File file = new File(mongoDbBackupLocation);

		if (!file.isDirectory()) {
			file.mkdirs();
		}

		mongoDbExceptionLocation = saveFolderLocation + File.separator + "MongoExceptionBackUp";

		file = new File(mongoDbExceptionLocation);

		if (!file.isDirectory()) {
			file.mkdirs();
		}

		fileBackupLocation = saveFolderLocation + File.separator + "fileBackUp";

		file = new File(fileBackupLocation);

		if (!file.isDirectory()) {
			file.mkdirs();
		}

		
		eRetailDataPath = saveFolderLocation + File.separator + "E-Retail_DATA";


		if (!file.isDirectory()) {
			file.mkdirs();
		}
		
		USER_PHOTO_PATH = eRetailDataPath + File.separator + "userPhoto";
		
		file = new File(USER_PHOTO_PATH);

		if (!file.isDirectory()) {
			file.mkdirs();
		}

		defaultUserPhotoPath = DOCUMENT_ROOT_PATH + File.separator + "resource" + File.separator + "default.jpg";
		
		// copy default data to new directories
		/*try {
			copyFileToDirectory(defaultImagePhotoPath, ITEM_PHOTO_PATH);
			copyFileToDirectory(defaultPatientPhotoPath, PATIENT_PHOTO_PATH);
			copyFileToDirectory(defaultUserPhotoPath, USER_PHOTO_PATH);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}*/
		
		TEMP_FILES_PATH = DOCUMENT_ROOT_PATH + File.separator + "E-Retail-Temp";

		File tempFolder = new File(TEMP_FILES_PATH);

		if (!tempFolder.isDirectory()) {
			tempFolder.mkdirs();
		}
		
		
	}
	
//	private static void copyFileToDirectory(String src, String destDir ) throws IOException {
//		
//		File srcFile = new File(src);
//		File destDirFile = new File(destDir);
//		
//		FileUtils.copyFileToDirectory(srcFile, destDirFile);
//	}
}
