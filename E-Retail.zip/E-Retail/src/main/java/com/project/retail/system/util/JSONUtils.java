package com.project.retail.system.util;

import java.io.IOException;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

public class JSONUtils {

	private static final ObjectMapper mapper = new ObjectMapper();
	private static Logger logger = Logger.getLogger(JSONUtils.class);

	public static String jsonFromObject(Object object)
			throws JsonGenerationException, JsonMappingException, IOException {
		
		mapper.setSerializationInclusion(Include.NON_NULL);
		return mapper.writeValueAsString(object);
	}

	public static <T> T objectFromJson(String json, Class<T> Klass)
			throws JsonParseException, JsonMappingException, IOException {
		
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		return mapper.readValue(json, Klass);
	}
	
	public static <T> T objectFromJson(String json, JavaType javaType) throws JsonParseException, JsonMappingException, IOException {
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		return mapper.readValue(json, javaType);
	}
	
	public static <T> T objectFromJson(String json, TypeReference<T> typeReference)
			throws JsonParseException, JsonMappingException, IOException {
		
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		return mapper.readValue(json, typeReference);
	}

	@SuppressWarnings("rawtypes")
	public static HashMap mapFromBean(Object object) throws JsonParseException,
			JsonMappingException, IOException {

		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		return mapper.readValue(jsonFromObject(object), HashMap.class);
	}
	
	/**
	 * Convert object to Formatted JSON String
	 *
	 * @param object
	 *            object to convert
	 * @return formatted json string
	 */
	public static String prettyPrinter(Object object) {

		if (object == null) {
			return null;
		}
		try {
			ObjectWriter writer = mapper.writer().withDefaultPrettyPrinter();
			return writer.writeValueAsString(object);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}
}
