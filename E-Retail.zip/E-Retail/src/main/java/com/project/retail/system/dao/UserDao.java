package com.project.retail.system.dao;

import static org.springframework.data.mongodb.core.query.Criteria.where;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.project.retail.system.constants.GetOnScrollType;
import com.project.retail.system.encyption.MD5Encryption;
import com.project.retail.system.model.SearchCriteria;
import com.project.retail.system.model.User;
import com.project.retail.system.model.Response.UserTypeModel;
import com.project.retail.system.util.SearchUtils;

@Repository
public class UserDao extends RetailDao<User, String> {

	private static final Logger logger = Logger.getLogger(UserDao.class);

	public User checkUser(String userId, String password) {

		
		Query query = new Query();
		query.addCriteria(Criteria.where("userId").is(userId));
		query.addCriteria(Criteria.where("password").is(password));
		
		/*Query query = new Query();
		query.addCriteria(where("userId").regex(
				"^" + SearchUtils.getRegexCompatibleString(userId) + "$", "i"));
		String encryptedPassword = MD5Encryption.encrypt(password);
		query.addCriteria(where("password").is(password));*/
		//query.addCriteria(where("status").is(true));

		/*query.addCriteria(Criteria.where("userId").is(userId));
		query.addCriteria(Criteria.where("password").is(password));*/

		return (User) findOne(query);
	}

	public Object autoSearchUser(String key, String value)
			throws IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, IntrospectionException {
		Query query = new Query();
		query.addCriteria(Criteria.where(key).regex(
				SearchUtils.getRegexPatternForSearchAtStart(value), "i"));
		query.addCriteria(Criteria.where("status").is(true));
		query.fields().include(key);
		query.with(new Sort(Sort.Direction.ASC, key));
		/*
		 * List<User> lstUsers = findAll(query);
		 * 
		 * List<String> lstvalues = new ArrayList<String>(); for (User user :
		 * lstUsers) { String temp = (new PropertyDescriptor(key,
		 * theType).getReadMethod() .invoke(user)).toString();
		 * lstvalues.add(temp); }
		 */
		List<String> lstvalues = distinct(key, query);
		return lstvalues;
	}

	public List<User> searchUser(List<SearchCriteria> list) {
		Query query = new Query();
		Order order = null;
		if (list != null && list.size() > 0) {
			Map<String, BasicDBList> map2 = new HashMap<String, BasicDBList>();
			map2.put("or", new BasicDBList());
			map2.put("and", new BasicDBList());

			for (SearchCriteria searchCriteria : list) {
				BasicDBObject objList = new BasicDBObject();
				String value = SearchUtils
						.getRegexPatternForSearchWithinText(searchCriteria
								.getValue());
				objList.put(searchCriteria.getKey(),
						Pattern.compile(value, Pattern.CASE_INSENSITIVE));

				map2.get(searchCriteria.getOperation()).add(objList);
				order = new Order(searchCriteria.getKey());

			}

			for (Map.Entry<String, BasicDBList> entry : map2.entrySet()) {

				if (entry.getValue().size() != 0) {
					query.addCriteria(new Criteria("$" + entry.getKey())
							.is(entry.getValue()));
				}
			}
		} else {
			order = new Order(Direction.DESC, "createdDate");
		}

		Sort sort = new Sort(order);
		query.with(sort);
		query.limit(100);

		logger.debug(query);

		return findAll(query);
	}

	public List<User> searchUser(SearchCriteria searchCriteria,
			List<String> roleAccessList, Integer pageSize, String lastId,
			Integer skip, GetOnScrollType getOnScrollType) {
		Query query = new Query();
		if (searchCriteria != null) {
			query.addCriteria(Criteria.where(searchCriteria.getKey()).regex(
					"^"
							+ SearchUtils
									.getRegexCompatibleString(searchCriteria
											.getValue()) + ".*", "i"));
		}
		if (roleAccessList != null && !roleAccessList.isEmpty()) {
			for (String access : roleAccessList) {
				query.addCriteria(Criteria.where("role.access." + access).is(
						true));
			}
		}

		query.fields().include("displayName");
		query.fields().include("userId");
		query.fields().include("userType");
		query.fields().include("subType");
		query.fields().include("roleId");
		query.fields().include("role.name");
		query.fields().include("status");
		query.fields().include("applyVisitCharge");
		query.fields().include("unitId");
		query.fields().include("isHeadOfUnit");

		if (pageSize != null) {
			query.limit(pageSize);
		}
		if (getOnScrollType != null) {
			switch (getOnScrollType) {
			case Id_Wise:
				if (lastId != null) {
					query.addCriteria(Criteria.where("_id").lt(
							new ObjectId(lastId)));
				}
				break;
			case Skip_Wise:
				query.skip(skip);
				break;
			default:
				break;
			}
		}

		query.with(new Sort(Direction.DESC, "_id"));
		return findAll(query);
	}

	public List<User> searchActiveUsers(SearchCriteria searchCriteria) {
		Query query = new Query();
		if (searchCriteria != null) {
			query.addCriteria(Criteria.where(searchCriteria.getKey()).regex(
					"^"
							+ SearchUtils
									.getRegexCompatibleString(searchCriteria
											.getValue()) + ".*", "i"));
		}
		query.addCriteria(Criteria.where("status").is(true));
		query.fields().include("userId");
		query.fields().include("userType");
		query.fields().include("displayName");
		return findAll(query);
	}

	public boolean checkDuplicateUserId(String userId) {

		Query query = new Query();

		query.addCriteria(where("userId").regex(
				"^" + SearchUtils.getRegexCompatibleString(userId) + "$", "i"));
		logger.debug(query.getQueryObject());

		return (count(query) == 0);
	}

	public boolean changePassword(User user) {
		logger.info(user);
		Query query = new Query();
		Update update = new Update();
		String encryptedPassword = MD5Encryption.encrypt(user.getPassword());
		query.addCriteria(Criteria.where("id").is(user.getId()));
		query.addCriteria(Criteria.where("password").is(encryptedPassword));

		/*String newEncryptedPassword = MD5Encryption.encrypt(user
				.getNewPassword());
		update.set("password", newEncryptedPassword);*/
		return findAndModify(query, update) != null;
	}

	public List<User> getSmallListByType(List<String> typeList) {
		Query query = new Query();
		if (typeList != null && !typeList.isEmpty()) {
			Criteria criteria = new Criteria();
			criteria.orOperator(Criteria.where("userType").in(typeList),
					Criteria.where("subType").in(typeList));
			query.addCriteria(criteria);
		}
		query.addCriteria(Criteria.where("status").is(true));
		query.fields().include("userId");
		query.fields().include("userType");
		query.fields().include("subType");
		query.fields().include("displayName");
		query.fields().include("isHeadOfUnit");
		query.fields().include("status");
		return findAll(query);
	}

	public List<ObjectId> getUserIdsByType(List<String> typeList) {
		Query query = new Query();
		if (typeList != null && !typeList.isEmpty()) {
			Criteria criteria = new Criteria();
			criteria.orOperator(Criteria.where("userType").in(typeList),
					Criteria.where("subType").in(typeList));
			query.addCriteria(criteria);
		}
		query.addCriteria(Criteria.where("status").is(true));
		return distinct("_id", query);
	}

	public void assignRoleToUsers(List<String> userIds, Object role) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").in(userIds));
		Update update = new Update();
		findAndModify(query, update);
	}

	public List<User> getAllUsersDisplayName() {
		Query query = new Query();
		query.fields().include("displayName");
		List<User> users = findAll(query);
		return users;
	}

	public List<User> findUserByRoleId(String roleId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("roleId").is(roleId));
		return findAll(query);
	}

	public void changePasswordByUser(User user) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(user.getId()));

		Update update = new Update();
		String encryptedPassword = MD5Encryption.encrypt(user.getPassword());
		update.set("password", encryptedPassword);
		update(query, update, "Change Password");
	}

//	public List<User> getSmallListByIds(List<String> userIds) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("_id").in(userIds));
//		query.fields().include("userId");
//		query.fields().include("displayName");
//		return find(query);
//	}

	public List<User> smallListBySingleType(UserTypeModel userTypeModel) {
		Query query = new Query();
		if (userTypeModel.getUserType() != null) {
			query.addCriteria(Criteria.where("userType").is(
					userTypeModel.getUserType()));
		}
		if (userTypeModel.getSubTypes() != null
				&& !userTypeModel.getSubTypes().isEmpty()) {
			query.addCriteria(Criteria.where("subType").in(
					userTypeModel.getSubTypes()));
		}
		query.addCriteria(Criteria.where("status").is(true));
		query.fields().include("userId");
		query.fields().include("userType");
		query.fields().include("subType");
		query.fields().include("displayName");
		query.fields().include("status");
		return findAll(query);
	}

	public List<User> smallListByMultipleType(List<UserTypeModel> userTypeModels) {

		ArrayList<User> result = new ArrayList<User>();
		if (userTypeModels != null && !userTypeModels.isEmpty()) {
			for (UserTypeModel userTypeModel : userTypeModels) {
				if (userTypeModel != null) {
					Query query = new Query();

					query.addCriteria(Criteria.where("userType").is(
							userTypeModel.getUserType()));
					if (!userTypeModel.getSubTypes().isEmpty()) {
						query.addCriteria(Criteria.where("subType").in(
								userTypeModel.getSubTypes()));
					}

					query.addCriteria(Criteria.where("status").is(true));

					query.fields().include("userId");
					query.fields().include("userType");
					query.fields().include("subType");
					query.fields().include("displayName");
					query.fields().include("status");
					List<User> users = find(query);
					if (users != null) {
						result.addAll(users);
					}
				}
			}
		}

		return result;
	}

//	private void removeOlderHead(String unitId) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("unitId").is(unitId));
//		query.addCriteria(Criteria.where("isHeadOfUnit").is(true));
//
//		Update update = new Update();
//		update.unset("unitId");
//		update.unset("isHeadOfUnit");
//
//		updateMulti(query, update);
//	}

//	private void removeUsersOfUnit(String unitId) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("unitId").is(unitId));
//		query.addCriteria(Criteria.where("isHeadOfUnit").is(false));
//
//		Update update = new Update();
//		update.set("unitId", null);
//		update.set("isHeadOfUnit", false);
//
//		updateMulti(query, update);
//	}

	public List<User> customAutoSearch(SearchCriteria searchCriteria,
			String userType, String userId, String accessName,
			List<String> subTypes, String displayName) {
		logger.info("searchCriteria:-- " + searchCriteria);
		Query query = new Query();
		if (userType != null && StringUtils.hasText(userType)) {
			query.addCriteria(Criteria.where("userType").is(userType));
		}
		if (subTypes != null && !subTypes.isEmpty()) {
			query.addCriteria(Criteria.where("subType").in(subTypes));
		}
		if (displayName != null && !displayName.isEmpty()) {
			String value = SearchUtils
					.getRegexPatternForSearchWithinText(displayName);
			query.addCriteria(Criteria.where("displayName").regex(value, "i"));
		}
		if (userId != null) {
			query.addCriteria(Criteria.where("userId").regex(
					SearchUtils.getRegexPatternForSearchAtStart(userId), "i"));
		}
		if (searchCriteria != null) {
			query.addCriteria(Criteria.where(searchCriteria.getKey()).regex(
					SearchUtils.getRegexPatternForSearchAtStart(searchCriteria
							.getValue()), "i"));
		}
		if (accessName != null && StringUtils.hasText(accessName)) {
			query.addCriteria(Criteria.where("role.access." + accessName).is(
					true));
		}
		query.addCriteria(Criteria.where("status").is(true));
		query.fields().include("userId");
		query.fields().include("displayName");
		query.fields().include("userType");
		query.fields().include("subType");
		return find(query);
	}

//	public List<User> findUnAllocatedNurse(UserTypeModel userTypeModel,
//			List<String> assignedNurseIds, boolean exclude) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("_id").nin(assignedNurseIds));
//		if (userTypeModel != null) {
//			if (userTypeModel.getUserType() != null) {
//				query.addCriteria(Criteria.where("userType").is(
//						userTypeModel.getUserType()));
//			}
//			if (exclude) {
//				query.addCriteria(Criteria.where("subType").nin(
//						userTypeModel.getSubTypes()));
//			} else {
//				query.addCriteria(Criteria.where("subType").in(
//						userTypeModel.getSubTypes()));
//			}
//		}
//		query.addCriteria(Criteria.where("status").is(true));
//		query.fields().include("userId");
//		query.fields().include("displayName");
//		query.fields().include("userType");
//		query.fields().include("subType");
//		return find(query);
//	}

//	public List<User> getUsersOfUnitByTypes(String unitId,
//			List<UserTypeModel> userTypeModels, Boolean status) {
//		Query query = new Query();
//
//		Criteria criteria = new Criteria();
//
//		ArrayList<Criteria> arrayList = new ArrayList<>();
//
//		logger.info(userTypeModels.toString());
//
//		if (userTypeModels != null && !userTypeModels.isEmpty()) {
//			for (UserTypeModel userTypeModel : userTypeModels) {
//				if (userTypeModel != null) {
//					if (userTypeModel.getUserType() != null) {
//						Criteria tempCriteria;
//						if (userTypeModel.getUserType().equals(
//								UserType.Type.Doctor)) {
//							tempCriteria = Criteria.where("unitId").is(unitId)
//									.and("userType")
//									.is(userTypeModel.getUserType().getName());
//							if (!userTypeModel.getSubTypes().isEmpty()) {
//								tempCriteria.and("subType").in(
//										userTypeModel.getSubTypes());
//							}
//						} else {
//							tempCriteria = Criteria.where("userType").is(
//									userTypeModel.getUserType().getName());
//
//							if (!userTypeModel.getSubTypes().isEmpty()) {
//								tempCriteria.and("subType").in(
//										userTypeModel.getSubTypes());
//							}
//						}
//						// criteria.orOperator(tempCriteria);
//						arrayList.add(tempCriteria);
//					}
//				}
//			}
//		}
//
//		criteria.orOperator(arrayList.toArray(new Criteria[arrayList.size()]));
//
//		logger.info(criteria.getCriteriaObject());
//
//		if (status != null) {
//			query.addCriteria(criteria.and("status").is(status));
//		}
//		query.fields().include("userId");
//		query.fields().include("displayName");
//		query.fields().include("isHeadOfUnit");
//		query.fields().include("unitId");
//		query.fields().include("userType");
//		query.fields().include("subType");
//
//		logger.info(query.getQueryObject());
//
//		return find(query);
//	}

	public List<User> getUserNameById(List<String> listofHistoryById) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").in(listofHistoryById));
		query.fields().include("displayName");
		return find(query);
	}

//	public Boolean checkUnitIdAssigned(String unitId) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("unitId").is(unitId));
//		return (findOne(query) != null);
//	}

//	public List<User> getUsersBySubType(List<String> subTypes) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("subType").in(subTypes));
//		query.fields().include("subType");
//		query.addCriteria(Criteria.where("status").is(true));
//		return find(query);
//	}

//	public List<String> getNotifyUsers(List<String> userTypes,
//			List<String> userSubTypes) {
//		List<String> userIds = new ArrayList<>();
//		Query query = new Query();
//		query.addCriteria(Criteria.where("userType").in(userTypes));
//		if (userSubTypes != null && !userSubTypes.isEmpty()) {
//			query.addCriteria(Criteria.where("subType").in(userSubTypes));
//		}
//		query.fields().include("_id");
//		for (User user : find(query)) {
//			userIds.add(user.getId());
//		}
//		return userIds;
//	}

//	public void mapEmployeeToUser(String userId, String employeeId) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("id").is(userId));
//		Update update = new Update();
//		update.set("employeeId", employeeId);
//		update(query, update, "Map User To Employee");
//	}

//	public void unsetEmployeeId(String employeeId) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("employeeId").is(employeeId));
//		Update update = new Update();
//		update.unset("employeeId");
//		update(query, update, "Unset employeeId");
//	}

//	public boolean checkMappingExist(String userId, String employeeId) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("id").is(userId));
//		query.addCriteria(Criteria.where("employeeId").exists(true));
//		return (count(query) != 0);
//	}

//	public User findByEmployeeId(String employeeId) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("employeeId").is(employeeId));
//		query.fields().include("employeeId");
//		return findOne(query);
//	}

//	public User findById(String userId) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("id").is(userId));
//		query.fields().include("employeeId");
//		query.fields().include("displayName");
//		return findOne(query);
//	}

//	public User getUserByUserId(String userId) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("userId").is(userId));
//		query.fields().include("employeeId");
//		query.fields().include("displayName");
//		return findOne(query);
//	}

	public User findOneSmallUserById(String id) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(id));
		query.fields().include("displayName");
		return findOne(query);
	}

	public List<User> getActiveUserByRole(List<String> roleAccessList) {
		Query query = new Query();
		query.with(new Sort(Direction.ASC, "userId"));
		query.addCriteria(Criteria.where("status").is(true));
		for (String access : roleAccessList) {
			query.addCriteria(Criteria.where("role.access." + access).is(true));
		}
		query.fields().include("userId");
		query.fields().include("displayName");
		query.limit(100);
		return findAll(query);
	}

	public List<User> getActiveUsersByAnyRole(List<String> roleAccessList) {
		Query query = new Query();
		query.with(new Sort(Direction.ASC, "userId"));
		Criteria criteria = Criteria.where("status").is(true);
		List<Criteria> criterias = new ArrayList<Criteria>();
		for (String access : roleAccessList) {
			criterias.add(Criteria.where("role.access." + access).is(true));
		}
		criteria.orOperator(criterias.toArray(new Criteria[criterias.size()]));
		query.addCriteria(criteria);
		query.fields().include("userId");
		query.fields().include("displayName");
		query.limit(100);
		return findAll(query);
	}

	public List<ObjectId> getUserIdForLogView(String userId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("userId").is(userId));
		return distinct("_id", query);
	}
}
