package com.project.retail.system.model;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "exceptionDetails")
public class ExceptionDetail extends AbstractDocument {

	private String ip;
	
	/**
	 *  MongoId of the user
	 */
	private String userId;
	private String version;
	private Date date;
	private String priority;
	private String exceptionClassName;
	private String exceptionMessage;
	private String userMessage;
	private String exeptionStacktrace;

	// domain address ex : slk004-desktop.slktechlabs.com
	private String domainAddress;
	// pc name : slk//abc.xyz
	private String pcUserName;
	// os name ex : linux , windows
	private String osName;
	private String appVersion;
	private String webServiceUrl;
	
	private String userLoginId;
	private String displayName;

	public String getExeptionStacktrace() {
		return exeptionStacktrace;
	}

	public void setExeptionStacktrace(String exeptionStacktrace) {
		this.exeptionStacktrace = exeptionStacktrace;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getExceptionClassName() {
		return exceptionClassName;
	}

	public void setExceptionClassName(String exceptionClassName) {
		this.exceptionClassName = exceptionClassName;
	}

	public String getExceptionMessage() {
		return exceptionMessage;
	}

	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	public String getUserMessage() {
		return userMessage;
	}

	public void setUserMessage(String userMessage) {
		this.userMessage = userMessage;
	}

	public String getDomainAddress() {
		return domainAddress;
	}

	public String getPcUserName() {
		return pcUserName;
	}

	public String getOsName() {
		return osName;
	}

	public void setDomainAddress(String domainAddress) {
		this.domainAddress = domainAddress;
	}

	public void setPcUserName(String pcUserName) {
		this.pcUserName = pcUserName;
	}

	public void setOsName(String osName) {
		this.osName = osName;
	}

	public String getAppVersion() {
		return appVersion;
	}

	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}

	public String getWebServiceUrl() {
		return webServiceUrl;
	}

	public void setServerUrl(String webServiceUrl) {
		this.webServiceUrl = webServiceUrl;
	}

	public void setWebServiceUrl(String webServiceUrl) {
		this.webServiceUrl = webServiceUrl;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getUserLoginId() {
		return userLoginId;
	}

	public void setUserLoginId(String userLoginId) {
		this.userLoginId = userLoginId;
	}

	@Override
	public String toString() {
		return "ExceptionDetail [ip=" + ip + ", userId=" + userId
				+ ", version=" + version + ", date=" + date + ", priority="
				+ priority + ", exceptionClassName=" + exceptionClassName
				+ ", exceptionMessage=" + exceptionMessage + ", userMessage="
				+ userMessage + ", exeptionStacktrace=" + exeptionStacktrace
				+ ", domainAddress=" + domainAddress + ", pcUserName="
				+ pcUserName + ", osName=" + osName + ", appVersion="
				+ appVersion + ", webServiceUrl=" + webServiceUrl
				+ ", userLoginId=" + userLoginId + ", displayName="
				+ displayName + "]";
	}
	
	

}
