package com.project.retail.system.constants;

import com.fasterxml.jackson.annotation.JsonValue;


public enum RoundOffType {

	POINT_FIVE("05", "0.5"), ONE("1", "1"), TWO("2", "2"), FIVE("5", "5"), TEN("10", "10");

	private String name;
	private String displayName;

	private RoundOffType(String expense_type, String store_display_name) {
		name = expense_type;
		displayName = store_display_name;
	}

	@JsonValue
	public String getName() {
		return name;
	}

	public String getDisplayName() {
		return displayName;
	}

	// @JsonCreator
	public static RoundOffType fromRoundOffName(String name) {
		for (RoundOffType roundOffType : RoundOffType.values()) {
			if (roundOffType.name.equalsIgnoreCase(name)) {
				return roundOffType;
			}
		}
		throw new IllegalArgumentException("Invalid RoundOffType : " + name);
	}

	@Override
	public String toString() {
		return displayName;
	}
}

