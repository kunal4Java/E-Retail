package com.project.retail.system.model.Response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.project.retail.system.constants.StatusConstants;

public class ResponseBean {

	private String message;
	private StatusConstants type;
	private String code;
	private Object data;
	@JsonIgnore
	private Object tempData;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	// public String getType() {
	// return type;
	// }
	//
	// public void setType(String type) {
	// this.type = type;
	//
	// if (type.equalsIgnoreCase(String.valueOf(StatusConstants.success))) {
	// code = "600";
	// } else {
	// code = "700";
	// }
	// }

	public StatusConstants getType() {
		return type;
	}

	public void setType(StatusConstants type) {
		this.type = type;

		if (type == StatusConstants.success) {
			code = "600";
		} else {
			code = "700";
		}
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public Object getTempData() {
		return tempData;
	}

	public void setTempData(Object tempData) {
		this.tempData = tempData;
	}

	@Override
	public String toString() {
		return "ResponseBean [message=" + message + ", type=" + type
				+ ", code=" + code + ", data=" + data + ", tempData="
				+ tempData + "]";
	}

}
