package com.project.retail.system.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.data.annotation.Transient;
 
/**
 * Custom Annotation Used for Find reference of particular Class in other class
 * for example:
 * Consider following lines from Visit Model:
 * <pre> 
 * private String patientId;
 * @CustomJoin(joinId = "patientId", value = { "patientId" }, isInclude = true)
 * private Patient patient;
 * </pre>
 *
 *this will fill patient object based on patientId in Visit when any find query on visit is executed
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
@Transient
public @interface CustomJoin {
	public String[] value() default {};
	public String joinId();//patientId in above example
	public boolean isInclude() default false;
	public String refId() default "_id";
	///public String accessBy ();//variable name for on/off
}
