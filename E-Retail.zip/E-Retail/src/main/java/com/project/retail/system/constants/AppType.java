package com.project.retail.system.constants;

public enum AppType {

	JavaFX("Java FX"), Android("Andriod"), IPhone("IPhone"), 
	ThirdParty("Third Party") , Webbrowser("Web browser") ;
	
	private String appTypeDisplayName;
	
	private AppType(String appTypeDisplayName) {
		this.appTypeDisplayName = appTypeDisplayName;
	}
	
	@Override
	public String toString() {
		return appTypeDisplayName;
	}
}
