package com.project.retail.system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.retail.system.dao.UserTypeMasterDao;
import com.project.retail.system.model.UserTypeMaster;

@Service
public class UserTypeMasterService extends RetailService<UserTypeMaster, String> {

	UserTypeMasterDao userTypeMasterDao;
	
	@Autowired
	public UserTypeMasterService(UserTypeMasterDao dao) {
		super(dao);
		this.userTypeMasterDao = dao;
	}

	public Boolean checkDuplicateType(UserTypeMaster userTypeMaster) {
		return userTypeMasterDao.checkDuplicateType(userTypeMaster);
	}

	public List<UserTypeMaster> list() {
		return userTypeMasterDao.list();
	}
	

}
