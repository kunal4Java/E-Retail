/**
 * 
 */
var MyUtils = {

	/**
	 * Set focus on the given selector if it is focusable. If selector is not
	 * focusable, it will look for input elements inside selector and select
	 * first input element that can be focused. If selector is not provided set
	 * focus on the first input element that is focusable. This method should
	 * called after page is loaded.
	 * 
	 * To select an input element Ex : Textfield with id = "textfield" :
	 * MyUtils.focusInput("#textfield");
	 * 
	 * To select first input element from div Ex : DIV with id = "container" :
	 * MyUtils.focusInput("#container");
	 * 
	 * To select first input element of perticular class (say "input-class") Ex :
	 * MyUtils.focusInput(".input-class");
	 * 
	 * To select first input from page: Ex : MyUtils.focusInput();
	 * 
	 */
	focusInput : function(selector) {

		// if selector exists
		if (selector) {
			// if found select first focusable selector
			if ($(selector + ":input:enabled:visible:first").length != 0) {
				// console.log("1 Element being focused : "+ selector +" : "+
				// $(selector));
				// console.log($(selector));
				// console.log($(selector +
				// ":input:enabled:visible:first").length);
				$(selector + ":input:enabled:visible:first").focus();
			} else {// else select first focusable input inside given selector
				// console.log("2 Element being focused : "+ $(selector + "
				// input:enabled:visible:first").attr("id"));
				$(selector + " input:enabled:visible:first").focus();
			}
		} else { // else select first focusable input
			// console.log("3 Element being focused : "+
			// ":input:enabled:visible:first" +" : "+
			// $(":input:enabled:visible:first").attr("id"));
			$(":input:enabled:visible:first").focus();
		}
	},

	/**
	 * check var is null , undefined , empty return : boolen
	 * 
	 */
	getIsEmpty : function(val) {

		if (val === undefined) {
			return true;
		} else if (val == null) {
			return true;
		} else if ($.isArray(val)) {
			return val.length <= 0;
		} else if (typeof val == "number" || val instanceof Number) {
			return false;
		} else if (typeof val == "string" || val instanceof String) {
			return (val.trim() == "");
		} else if (val instanceof Date) {
			return false;
		} else {
			return $.isEmptyObject(val);
		}

		// console.log(typeof val);
		// return (val !== undefined && val != null && val.length <= 0) ? true :
		// false;

	},
	
	/**
	 * check var is null , undefined , empty return : boolen
	 * 
	 */
	getDefaultVal : function(val) {
		if(this.getIsEmpty(val)) {
			return "-";
		} 
		return val;
	},

	/**
	 * get Age In days and month according to birth data that are passed into
	 * argument
	 */
	getAgeInDayMonthsAndYearsFromDOB : function getAge(dateString) {

		var now = new Date();
		var yearNow = now.getYear(); // Out Date Picker Is Support Upto 1900
		var monthNow = now.getMonth();
		var dateNow = now.getDate();
		
		var dob = new Date(dateString);
		var yearDob = dob.getYear();
		var monthDob = dob.getMonth();
		var dateDob = dob.getDate();
		
		var age = {};
		var monthAge=0;
		var dateAge=0;

	  // Invalid When Date Of Birth Is Greater Than Current Date
		if (now > dateString) {
			yearAge = yearNow - yearDob;
			
			if (monthNow >= monthDob)
				monthAge = monthNow - monthDob;
			else {
				yearAge--;
				monthAge = 12 + monthNow - monthDob;
			}
			
			if (dateNow >= dateDob)
				dateAge = dateNow - dateDob;
			else {
				monthAge--;
				dateAge = 31 + dateNow - dateDob;
				if (monthAge < 0) {
					monthAge = 11;
					yearAge--;
				}
			 }
			
			age = {
				years : yearAge,
				months : monthAge,
				days : dateAge
			};

			if (age.years == 0) {
				return age.months + "m " + age.days + "d";
			} else {
				return age.years + "y " + age.months + "m";
			}
		} else {
			return "InValid";
		}
	},
	
	getStringFromBoolean : function(bool) {
		if (bool) {
			return "Yes";
		} else {
			return "No";
		}
	},

	getStringValue : function(string) {
		if (string == "" || typeof string == 'undefined') {
			return "-";
		} else {
			return string;
		}
	},

	getStingOrEmpty : function(string) {
		if (string == null || string == 'undefined') {
			return "";
		}
		return string;
	},

	getDoubleOnly : function(val) {

		var id = $(val).attr('id');

		$(val).bind(
				"keypress",
				function(evt) {

					var charCode = (evt.which) ? evt.which : event.keyCode;

					if (charCode == 46) {
						var inputValue = document.getElementById(id).value;

						if (inputValue.length > 0) {

							if (inputValue == '.') {
								return false;
							}

							if (inputValue.indexOf('.') > 0) {
								return false;
							} else {
								return true;
							}

						} else {
							return false;
						}

					}
					if (charCode != 46 && charCode > 31
							&& (charCode < 48 || charCode > 57)) {
						return false;
					}
					return true;

				});
		$(val).bind("paste", function(e) {
			return false;
		});
		$(val).bind("drop", function(e) {
			return false;
		});
	},

	getIntegerOnly : function(val) {
		var specialKeys = new Array();
		specialKeys.push(8);

		$(val).bind(
				"keypress",
				function(e) {
					var keyCode = e.which ? e.which : e.keyCode;
					var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys
							.indexOf(keyCode) != -1);
					return ret;
				});
		$(val).bind("paste", function(e) {
			return false;
		});
		$(val).bind("drop", function(e) {
			return false;
		});
	},
	getDoubleFromValue:function(doubleValue){
		if(this.getIsEmpty(doubleValue)) {
			return 0.0;
		} 
		return doubleValue;
	},

	// Get Sorted List
	getSortedDropDown : function(selector) {
		$('#' + selector).html(
				$('#' + selector + ' option').sort(function(x, y) {
					return $(x).val() < $(y).val() ? -1 : 1;
				}));
		$('#' + selector).get(0).selectedIndex = 0;
	}
}
